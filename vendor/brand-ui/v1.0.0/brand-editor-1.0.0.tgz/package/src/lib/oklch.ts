/**
 * Minimal oklch() → #rrggbb[aa] conversion (Björn Ottosson's OKLab math).
 *
 * The semantic tokens are authored in oklch; the mermaid engine's color lib
 * (khroma) only speaks hex/rgb/hsl. Browsers don't reliably re-serialize
 * oklch to rgb (canvas fillStyle keeps the oklch string in Chromium), so the
 * conversion happens here, dependency-free. Out-of-gamut channels clamp.
 */

const NUM = String.raw`([0-9.]+%?)`;
const OKLCH_RE = new RegExp(
  String.raw`^oklch\(\s*${NUM}\s+${NUM}\s+([0-9.]+)(?:deg)?\s*(?:/\s*${NUM})?\s*\)$`,
  "i",
);

function channel(raw: string, percentScale: number): number {
  return raw.endsWith("%") ? (parseFloat(raw) / 100) * percentScale : parseFloat(raw);
}

function srgbGamma(linear: number): number {
  const c = Math.min(1, Math.max(0, linear));
  return c <= 0.0031308 ? 12.92 * c : 1.055 * Math.pow(c, 1 / 2.4) - 0.055;
}

function hexByte(v: number): string {
  return Math.round(v * 255)
    .toString(16)
    .padStart(2, "0");
}

/** Convert an `oklch(L C H [/ A])` string to hex. Returns null for non-oklch input. */
export function oklchToHex(value: string): string | null {
  const m = OKLCH_RE.exec(value.trim());
  if (!m) return null;

  const L = channel(m[1]!, 1);
  const C = channel(m[2]!, 0.4);
  const H = parseFloat(m[3]!);
  const alpha = m[4] ? channel(m[4], 1) : 1;

  // oklch → oklab
  const hr = (H * Math.PI) / 180;
  const a = C * Math.cos(hr);
  const b = C * Math.sin(hr);

  // oklab → LMS (cube roots) → linear sRGB
  const l_ = L + 0.3963377774 * a + 0.2158037573 * b;
  const m_ = L - 0.1055613458 * a - 0.0638541728 * b;
  const s_ = L - 0.0894841775 * a - 1.291485548 * b;
  const l3 = l_ ** 3;
  const m3 = m_ ** 3;
  const s3 = s_ ** 3;

  const r = 4.0767416621 * l3 - 3.3077115913 * m3 + 0.2309699292 * s3;
  const g = -1.2684380046 * l3 + 2.6097574011 * m3 - 0.3413193965 * s3;
  const bl = -0.0041960863 * l3 - 0.7034186147 * m3 + 1.707614701 * s3;

  const hex = `#${hexByte(srgbGamma(r))}${hexByte(srgbGamma(g))}${hexByte(srgbGamma(bl))}`;
  return alpha < 1 ? `${hex}${hexByte(Math.min(1, Math.max(0, alpha)))}` : hex;
}
