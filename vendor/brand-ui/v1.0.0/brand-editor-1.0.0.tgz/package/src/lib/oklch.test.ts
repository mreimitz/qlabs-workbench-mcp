import { describe, expect, it } from "vitest";

import { oklchToHex } from "./oklch";

describe("oklchToHex", () => {
  it("converts white and black exactly", () => {
    expect(oklchToHex("oklch(1 0 0)")).toBe("#ffffff");
    expect(oklchToHex("oklch(0 0 0)")).toBe("#000000");
  });

  it("converts a mid blue to a blue-dominant hex", () => {
    const hex = oklchToHex("oklch(0.6 0.15 240)")!;
    expect(hex).toMatch(/^#[0-9a-f]{6}$/);
    const [r, , b] = [hex.slice(1, 3), hex.slice(3, 5), hex.slice(5, 7)].map((h) =>
      parseInt(h, 16),
    );
    expect(b!).toBeGreaterThan(r!);
  });

  it("supports percentage lightness, deg hue, and alpha", () => {
    expect(oklchToHex("oklch(100% 0 90deg)")).toBe("#ffffff");
    expect(oklchToHex("oklch(1 0 0 / 0.5)")).toBe("#ffffff80");
    expect(oklchToHex("oklch(1 0 0 / 50%)")).toBe("#ffffff80");
  });

  it("returns null for non-oklch input", () => {
    expect(oklchToHex("#fff")).toBeNull();
    expect(oklchToHex("rgb(1, 2, 3)")).toBeNull();
    expect(oklchToHex("var(--primary)")).toBeNull();
  });

  it("clamps out-of-gamut chroma instead of producing NaN", () => {
    const hex = oklchToHex("oklch(0.5 0.4 30)")!;
    expect(hex).toMatch(/^#[0-9a-f]{6}$/);
  });
});
