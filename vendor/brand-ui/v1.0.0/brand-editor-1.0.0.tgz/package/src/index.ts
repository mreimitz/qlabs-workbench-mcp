/**
 * @brand/editor — a token-themed Monaco (VS Code) editor wrapped as brand-ui
 * components.
 *
 * Monaco is a self-rendering editor engine; this package wraps it the way
 * @brand/flow wraps React Flow and @brand/data wraps TanStack. The editing
 * surface + widgets are Monaco's, recolored from the active brand theme via the
 * theming bridge; the chrome (toolbar, file tabs, copy button) is brand-ui.
 *
 * Worker setup (for completions/diagnostics) — import ONCE at the app entry:
 *   import "@brand/editor/monaco-environment";   // Vite apps
 */
export { CodeEditor, type CodeEditorProps, type MonacoCodeEditor } from "./code-editor";
export { DiffEditor, type DiffEditorProps, type MonacoDiffEditor } from "./diff-editor";
export {
  MarkdownEditor,
  type MarkdownEditorProps,
  type MarkdownEditorHandle,
  type EmbedAssetFn,
} from "./markdown-editor";
export { CodeWorkspace, type CodeWorkspaceProps, type EditorFile } from "./code-workspace";
export { EditorToolbar, type EditorToolbarProps } from "./editor-toolbar";
export { EditorContextMenu, type EditorContextMenuProps } from "./editor-context-menu";
export { CopyButton, type CopyButtonProps } from "./copy-button";

// Theming bridge + language helpers (advanced consumers / custom chrome).
export { applyBrandTheme, buildBrandThemeData, brandThemeId } from "./lib/monaco-theme-bridge";
export { useDataTheme, type DataThemeState } from "./lib/use-data-theme";
export { EDITOR_LANGUAGES, languageLabel, type EditorLanguage } from "./lib/languages";

// Re-export the monaco namespace so consumers can build custom editors / wire
// commands without adding a direct dependency.
export * as monaco from "monaco-editor";
