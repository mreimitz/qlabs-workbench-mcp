"use client";

/**
 * MarkdownWorkspace — the hybrid markdown authoring surface for the Workbench.
 *
 * One markdown value, three modes (a @brand/ui ToggleGroup):
 *  - "source"  : Monaco CodeEditor(markdown) + the MarkdownToolbar
 *  - "wysiwyg" : the Milkdown MarkdownEditor (direct manipulation)
 *  - "split"   : source ↔ the branded MarkdownPreview (drag-resizable)
 *
 * The value is shared across modes, so switching is lossless. Controlled
 * (`value`/`onChange`) or uncontrolled (`defaultValue`); same for `mode`.
 */
import {
  ResizableHandle,
  ResizablePanel,
  ResizablePanelGroup,
  Toggle,
  ToggleGroup,
  ToggleGroupItem,
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@brand/ui";
import { cn } from "@brand/ui/lib/cn";
import { Columns2, Eye, Focus, SquareCode } from "lucide-react";
import { forwardRef, useEffect, useMemo, useRef, useState, type HTMLAttributes } from "react";

import { attachCalcMonaco } from "../calc-block/calc-editor-monaco";
import type { CalcEditorHooks } from "../calc-block/types";
import { CodeEditor, type MonacoCodeEditor } from "../code-editor";
import { parseFrontmatter } from "../lib/markdown/frontmatter";
import { mergeNormalizedEdit } from "../lib/markdown/merge";
import { MarkdownEditor, type MarkdownEditorHandle, type EmbedAssetFn } from "../markdown-editor";
import type { SlashCommand } from "../markdown-editor/slash";
import { MarkdownPreview } from "../markdown-preview";
import { MarkdownToolbar } from "../markdown-toolbar";
import { topLevelBlockOf, typewriterDelta } from "./focus-writing";

export type MarkdownWorkspaceMode = "source" | "wysiwyg" | "split";

export interface MarkdownWorkspaceProps extends Omit<
  HTMLAttributes<HTMLDivElement>,
  "onChange" | "defaultValue"
> {
  value?: string;
  defaultValue?: string;
  onChange?: (markdown: string) => void;
  mode?: MarkdownWorkspaceMode;
  defaultMode?: MarkdownWorkspaceMode;
  onModeChange?: (mode: MarkdownWorkspaceMode) => void;
  /**
   * Start with FOCUS WRITING on (wysiwyg mode): typewriter scrolling keeps
   * the caret vertically centered and inactive paragraphs dim. Toggleable in
   * the editor's mode row.
   */
  defaultFocusWriting?: boolean;
  /**
   * The `/` command menu in the WYSIWYG (preview-edit) pane. `true` (default)
   * uses the built-in brand commands; pass a config to extend/replace them, or
   * `false` to disable. Forwarded to {@link MarkdownEditor}.
   */
  slashMenu?: boolean | { commands?: SlashCommand[]; trigger?: string };
  /**
   * Opt-in calc authoring inside ```calc fences (off by default). Wired to BOTH
   * surfaces: the Monaco source pane (highlight + autocomplete + result inlays)
   * and the WYSIWYG pane (highlight + result inlays). Supply the consumer's
   * `tokenize` / `evaluate` / `complete` hooks; the library bundles no calc engine.
   */
  calc?: CalcEditorHooks;
  /**
   * Host-provided callback for image paste/drop embedding in the WYSIWYG pane.
   * Forwarded to {@link MarkdownEditor}. See `MarkdownEditorProps.onEmbedAsset`
   * for the full contract.
   */
  onEmbedAsset?: EmbedAssetFn;
}

const MODES: { value: MarkdownWorkspaceMode; label: string; icon: typeof Eye }[] = [
  { value: "source", label: "Source", icon: SquareCode },
  { value: "split", label: "Split", icon: Columns2 },
  { value: "wysiwyg", label: "Preview-edit", icon: Eye },
];

export const MarkdownWorkspace = forwardRef<HTMLDivElement, MarkdownWorkspaceProps>(
  function MarkdownWorkspace(
    {
      value,
      defaultValue,
      onChange,
      mode,
      defaultMode = "split",
      onModeChange,
      defaultFocusWriting = false,
      slashMenu = true,
      calc,
      onEmbedAsset,
      className,
      ...props
    },
    ref,
  ) {
    const isControlled = value !== undefined;
    const [internalValue, setInternalValue] = useState(value ?? defaultValue ?? "");
    const markdown = isControlled ? value : internalValue;

    const [internalMode, setInternalMode] = useState<MarkdownWorkspaceMode>(defaultMode);
    const activeMode = mode ?? internalMode;

    const [monaco, setMonaco] = useState<MonacoCodeEditor | null>(null);

    /* ------------------------- calc authoring (#220) ------------------------ */
    // Read the calc hooks through a ref so a fresh `calc` object identity never
    // re-attaches the Monaco layer; only toggling the feature on/off does.
    const calcRef = useRef<CalcEditorHooks | undefined>(calc);
    calcRef.current = calc;
    const calcEnabled = calc != null;

    useEffect(() => {
      if (!monaco || !calcEnabled) return;
      // Let calc completions surface as you type inside the fence (markdown
      // otherwise suppresses quick suggestions outside comments/strings).
      monaco.updateOptions({
        quickSuggestions: { other: true, comments: false, strings: false },
      });
      return attachCalcMonaco(monaco, () => calcRef.current);
    }, [monaco, calcEnabled]);

    /* ------------------- split-view scroll synchronization ------------------ */
    // Line-accurate (not percentage) sync: preview blocks carry
    // `data-sourcepos` in frontmatter-STRIPPED coordinates; Monaco lines are
    // full-source — bridge with the stripped-line offset.
    const previewPaneRef = useRef<HTMLDivElement | null>(null);
    const scrollLock = useRef<"editor" | "preview" | null>(null);
    const lockTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

    const fmOffset = useMemo(() => {
      try {
        const body = parseFrontmatter(markdown).content;
        return markdown.split("\n").length - body.split("\n").length;
      } catch {
        return 0;
      }
    }, [markdown]);

    const lock = (owner: "editor" | "preview") => {
      scrollLock.current = owner;
      if (lockTimer.current) clearTimeout(lockTimer.current);
      lockTimer.current = setTimeout(() => {
        scrollLock.current = null;
      }, 150);
    };

    // Editor → preview.
    useEffect(() => {
      if (!monaco || activeMode !== "split") return;
      const disposable = monaco.onDidScrollChange(() => {
        if (scrollLock.current === "preview") return;
        const range = monaco.getVisibleRanges()[0];
        const host = previewPaneRef.current;
        if (!range || !host) return;
        const line = range.startLineNumber - fmOffset;
        let target: HTMLElement | null = null;
        for (const el of host.querySelectorAll<HTMLElement>("[data-sourcepos]")) {
          const end = Number(el.dataset.sourcepos?.split(":")[1]);
          if (end >= line) {
            target = el;
            break;
          }
        }
        if (!target) return;
        lock("editor");
        host.scrollTop =
          target.getBoundingClientRect().top -
          host.getBoundingClientRect().top +
          host.scrollTop -
          12;
      });
      return () => disposable.dispose();
    }, [monaco, activeMode, fmOffset]);

    // Preview → editor.
    const onPreviewScroll = () => {
      if (scrollLock.current === "editor" || !monaco || activeMode !== "split") return;
      const host = previewPaneRef.current;
      if (!host) return;
      const hostTop = host.getBoundingClientRect().top;
      for (const el of host.querySelectorAll<HTMLElement>("[data-sourcepos]")) {
        if (el.getBoundingClientRect().bottom >= hostTop) {
          const start = Number(el.dataset.sourcepos?.split(":")[0]);
          if (!Number.isNaN(start)) {
            lock("preview");
            monaco.setScrollTop(monaco.getTopForLineNumber(Math.max(1, start + fmOffset)));
          }
          return;
        }
      }
    };

    const setMarkdown = (next: string) => {
      if (!isControlled) setInternalValue(next);
      onChange?.(next);
    };

    /* ------------------ lossless WYSIWYG editing (WI-1) ------------------ */
    // Milkdown re-serializes the WHOLE document on every edit, normalizing
    // formatting the user never touched — a one-line edit became a whole-file
    // diff. Capture the editor's pre-edit serialization as a BASELINE and
    // merge each emission back onto the byte-exact original: unedited blocks
    // keep their original bytes.
    const wysiwygRef = useRef<MarkdownEditorHandle | null>(null);
    const wysiwygBase = useRef<{ original: string; baseline: string | null } | null>(null);

    useEffect(() => {
      if (activeMode !== "wysiwyg") {
        wysiwygBase.current = null;
        return;
      }
      // Capture at mode entry; the editor is uncontrolled while in wysiwyg,
      // so the workspace buffer is the only writer.
      const original = markdown;
      wysiwygBase.current = { original, baseline: null };
      const poll = setInterval(() => {
        const base = wysiwygBase.current;
        if (!base || base.baseline !== null) {
          clearInterval(poll);
          return;
        }
        const s = wysiwygRef.current?.serialized();
        if (s != null) {
          base.baseline = s;
          clearInterval(poll);
        }
      }, 50);
      const stop = setTimeout(() => clearInterval(poll), 5000);
      return () => {
        clearInterval(poll);
        clearTimeout(stop);
      };
      // eslint-disable-next-line react-hooks/exhaustive-deps -- capture markdown at ENTRY only
    }, [activeMode]);

    const onWysiwygChange = (emitted: string) => {
      const base = wysiwygBase.current;
      // Baseline captured before the first keystroke → merge; otherwise fall
      // back to the raw emission (rare boot race — old behavior, never worse).
      const next =
        base && base.baseline !== null
          ? mergeNormalizedEdit(base.original, base.baseline, emitted)
          : emitted;
      setMarkdown(next);
    };

    /* ---------------- focus writing (Ulysses Phase A, wysiwyg) ---------------- */
    // Typewriter scrolling + paragraph focus, driven from OUTSIDE the engine:
    // selectionchange marks the active top-level block (CSS dims the rest);
    // right after typing, the pane re-centers the caret into a middle band.
    const [focusWriting, setFocusWriting] = useState(defaultFocusWriting);
    const wysiwygPaneRef = useRef<HTMLDivElement | null>(null);
    const lastInputAt = useRef(0);

    useEffect(() => {
      if (!(focusWriting && activeMode === "wysiwyg")) return;
      const pane = wysiwygPaneRef.current;
      if (!pane) return;
      let active: Element | null = null;

      const onSelectionChange = () => {
        const root = pane.querySelector<HTMLElement>(".ProseMirror");
        if (!root) return;
        const sel = document.getSelection();
        const node = sel?.anchorNode ?? null;
        if (!node || !root.contains(node)) return;
        const block = topLevelBlockOf(root, node);
        if (block !== active) {
          active?.classList.remove("wb-fw-active");
          block?.classList.add("wb-fw-active");
          active = block;
        }
        // Re-center only right after typing — a mouse click must not yank
        // the viewport (Ulysses recenters while WRITING, not while aiming).
        if (Date.now() - lastInputAt.current < 200 && sel && sel.rangeCount > 0) {
          const range = sel.getRangeAt(0).getBoundingClientRect();
          const caret = range.height > 0 ? range : (active?.getBoundingClientRect() ?? range);
          const host = pane.getBoundingClientRect();
          const delta = typewriterDelta(caret.top, caret.height, host.top, host.height);
          if (delta !== 0) pane.scrollTop += delta;
        }
      };
      const onInput = () => {
        lastInputAt.current = Date.now();
      };

      document.addEventListener("selectionchange", onSelectionChange);
      pane.addEventListener("input", onInput, true);
      onSelectionChange();
      return () => {
        document.removeEventListener("selectionchange", onSelectionChange);
        pane.removeEventListener("input", onInput, true);
        active?.classList.remove("wb-fw-active");
      };
    }, [focusWriting, activeMode]);

    const setMode = (next: string) => {
      if (next !== "source" && next !== "split" && next !== "wysiwyg") return;
      if (!mode) setInternalMode(next);
      onModeChange?.(next);
    };

    const modeToggle = (
      <TooltipProvider delayDuration={300}>
        {/* Segmented mode switch — same recessed-track / raised-segment
            grammar as every other mode control (Tabs, Read/Write). */}
        <ToggleGroup
          type="single"
          value={activeMode}
          onValueChange={setMode}
          variant="segmented"
          size="sm"
          className="rounded-md p-0.5"
        >
          {MODES.map(({ value: m, label, icon: Icon }) => (
            <Tooltip key={m}>
              <TooltipTrigger asChild>
                <ToggleGroupItem
                  value={m}
                  aria-label={label}
                  className="h-6 min-w-7 rounded-[5px] px-2"
                >
                  <Icon className="size-4" />
                </ToggleGroupItem>
              </TooltipTrigger>
              <TooltipContent>{label}</TooltipContent>
            </Tooltip>
          ))}
        </ToggleGroup>
      </TooltipProvider>
    );

    const sourcePane = (
      <CodeEditor
        language="markdown"
        value={markdown}
        onChange={setMarkdown}
        onMount={(editor) => {
          // Markdown is prose: soft-wrap so the source pane lays out like the
          // preview (line-based scroll sync stays accurate either way, but
          // matching layouts keep the two panes visually in step).
          editor.updateOptions({ wordWrap: "on" });
          setMonaco(editor);
        }}
      />
    );

    return (
      <div
        ref={ref}
        data-testid="markdown-workspace"
        className={cn("flex h-full min-h-0 flex-col overflow-hidden", className)}
        {...props}
      >
        {activeMode === "wysiwyg" ? (
          <div className="flex h-10 shrink-0 items-center justify-end gap-2 border-b border-border bg-surface px-2">
            <TooltipProvider delayDuration={300}>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Toggle
                    size="sm"
                    pressed={focusWriting}
                    onPressedChange={setFocusWriting}
                    aria-label="Focus writing"
                    className="h-6 gap-1.5 px-2 text-caption"
                  >
                    <Focus className="size-3.5" aria-hidden="true" /> Focus
                  </Toggle>
                </TooltipTrigger>
                <TooltipContent>Typewriter scrolling · inactive paragraphs dim</TooltipContent>
              </Tooltip>
            </TooltipProvider>
            {modeToggle}
          </div>
        ) : (
          <MarkdownToolbar editor={monaco} actions={modeToggle} />
        )}

        <div className="min-h-0 flex-1">
          {activeMode === "source" ? sourcePane : null}

          {activeMode === "wysiwyg" ? (
            <div
              ref={wysiwygPaneRef}
              data-focus-writing={focusWriting ? "" : undefined}
              className="h-full overflow-auto p-4"
            >
              {/* UNCONTROLLED while in wysiwyg: feeding the merged buffer back
                  would replaceAll on every keystroke (cursor loss + echo
                  loops). The buffer receives merged text via onWysiwygChange;
                  mode switches remount the editor from the buffer. */}
              <MarkdownEditor
                ref={wysiwygRef}
                defaultValue={markdown}
                onChange={onWysiwygChange}
                slashMenu={slashMenu}
                calc={calc}
                onEmbedAsset={onEmbedAsset}
                className="border-0"
              />
            </div>
          ) : null}

          {activeMode === "split" ? (
            <ResizablePanelGroup direction="horizontal">
              <ResizablePanel defaultSize={50} minSize={25}>
                {sourcePane}
              </ResizablePanel>
              <ResizableHandle withHandle />
              <ResizablePanel defaultSize={50} minSize={25}>
                <div
                  ref={previewPaneRef}
                  onScroll={onPreviewScroll}
                  className="h-full overflow-auto p-5"
                >
                  <MarkdownPreview>{markdown}</MarkdownPreview>
                </div>
              </ResizablePanel>
            </ResizablePanelGroup>
          ) : null}
        </div>
      </div>
    );
  },
);
