import { cleanup, render, screen, waitFor } from "@testing-library/react";
import { afterEach, expect, test, vi } from "vitest";

// Monaco can't mount in jsdom — mock the engine so the workspace (which imports
// CodeEditor) loads. The "wysiwyg" mode under test renders Milkdown, not Monaco.
vi.mock("monaco-editor", () => ({
  editor: {
    create: vi.fn(() => ({
      onDidChangeModelContent: vi.fn(() => ({ dispose: vi.fn() })),
      getValue: vi.fn(() => ""),
      setValue: vi.fn(),
      getModel: vi.fn(() => ({ dispose: vi.fn() })),
      updateOptions: vi.fn(),
      dispose: vi.fn(),
    })),
    createModel: vi.fn(() => ({ dispose: vi.fn() })),
    setModelLanguage: vi.fn(),
    defineTheme: vi.fn(),
    setTheme: vi.fn(),
  },
  Uri: { parse: (s: string) => ({ toString: () => s }) },
  Range: class {},
  Selection: class {},
}));

import { MarkdownWorkspace } from "./markdown-workspace";

afterEach(cleanup);

test("renders the mode switcher and the WYSIWYG editor", async () => {
  render(<MarkdownWorkspace defaultMode="wysiwyg" defaultValue="# Hello" />);
  expect(screen.getByTestId("markdown-workspace")).toBeInTheDocument();
  // Three modes are offered.
  expect(screen.getByRole("radio", { name: "Source" })).toBeInTheDocument();
  expect(screen.getByRole("radio", { name: "Split" })).toBeInTheDocument();
  // Milkdown mounts the heading.
  await waitFor(() => expect(screen.getByText("Hello")).toBeInTheDocument());
});
