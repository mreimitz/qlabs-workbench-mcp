import type { Meta, StoryObj } from "@storybook/react-vite";
import { expect, within } from "storybook/test";
import { useState } from "react";
import { MarkdownWorkspace } from "./markdown-workspace";

const SAMPLE = `# Migration Plan

Author on the left, branded preview on the right.

:::callout{type="warning" title="Heads up"}
This block renders as an Alert in the preview.
:::

::metric{label="Scope" value="1,245" description="frozen report candidates"}
`;

const meta = {
  title: "Editor/MarkdownWorkspace",
  component: MarkdownWorkspace,
  tags: ["autodocs"],
  parameters: {
    layout: "fullscreen",
    docs: {
      description: {
        component:
          "The hybrid markdown surface: one value, three modes (Source = Monaco, Split = " +
          "source + branded preview, Preview-edit = Milkdown WYSIWYG), switched via a " +
          "@brand/ui ToggleGroup. The MarkdownToolbar is exercised in Source/Split modes.",
      },
    },
  },
} satisfies Meta<typeof MarkdownWorkspace>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Split: Story = {
  render: function SplitStory() {
    const [value, setValue] = useState(SAMPLE);
    return (
      <div className="h-[520px] border-t border-border">
        <MarkdownWorkspace value={value} onChange={setValue} defaultMode="split" />
      </div>
    );
  },
  play: async ({ canvasElement }) => {
    const canvas = within(canvasElement);
    // The mode switch (radiogroup) and formatting toolbar render immediately.
    await expect(canvas.getByRole("radio", { name: "Split" })).toBeInTheDocument();
    await expect(canvas.getByRole("toolbar", { name: "Markdown formatting" })).toBeInTheDocument();
  },
};

const LONG = `# Focus writing

${Array.from({ length: 12 }, (_, i) => `Paragraph ${i + 1} — keep typing and the caret stays in a vertical band while the page moves underneath; every paragraph except the active one dims.`).join("\n\n")}
`;

/**
 * Focus writing (Ulysses Phase A): typewriter scrolling + paragraph focus in
 * the WYSIWYG mode. The "Focus" toggle in the mode row turns it on; the
 * active paragraph stays at full opacity while the rest dim.
 */
export const FocusWriting: Story = {
  render: function FocusWritingStory() {
    const [value, setValue] = useState(LONG);
    return (
      <div className="h-[520px] border-t border-border">
        <MarkdownWorkspace
          value={value}
          onChange={setValue}
          defaultMode="wysiwyg"
          defaultFocusWriting
        />
      </div>
    );
  },
  play: async ({ canvasElement }) => {
    const canvas = within(canvasElement);
    const toggle = await canvas.findByRole("button", { name: "Focus writing" });
    await expect(toggle).toHaveAttribute("aria-pressed", "true");
  },
};
