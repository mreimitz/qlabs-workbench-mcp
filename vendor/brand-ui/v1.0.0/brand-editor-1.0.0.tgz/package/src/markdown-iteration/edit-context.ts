"use client";

/**
 * The seam between an iteration node-view's `⋯` "Edit template…" affordance and
 * the {@link IterationTemplateDialog} that fulfils it.
 *
 * Decoupled ON PURPOSE: the node-view (inside `MarkdownEditor`) must NOT import the
 * dialog (which embeds a whole `MarkdownWorkspace` — a heavy, cyclic dependency).
 * Instead the node-view emits an edit REQUEST through this context; the consumer
 * (above the editor) renders the dialog and writes the result back via `onSave`.
 * When no handler is provided, the `⋯` button is hidden and the template stays
 * editable inline. This keeps `@brand/editor` a presentation layer — the app owns
 * how/where the modal mounts.
 */
import { createContext } from "react";

export interface IterationEditRequest {
  /** Which directive asked to be edited. */
  kind: "iterate" | "pivot";
  /** The current template markdown (the node body, serialized). */
  template: string;
  /** Apply the edited template back to the node. */
  onSave: (template: string) => void;
}

/** A consumer handler that opens the template editor for a request. */
export type IterationEditHandler = (request: IterationEditRequest) => void;

/** Provide a handler to enable the node-view `⋯` re-edit affordance. */
export const IterationEditContext = createContext<IterationEditHandler | null>(null);
