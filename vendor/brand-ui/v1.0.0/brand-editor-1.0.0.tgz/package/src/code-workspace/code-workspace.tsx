"use client";

import { Tabs, TabsList, TabsTrigger } from "@brand/ui";
import { cn } from "@brand/ui/lib/cn";
import { forwardRef, useCallback, useState, type CSSProperties, type HTMLAttributes } from "react";
import { CodeEditor } from "../code-editor";
import { CopyButton } from "../copy-button";

export interface EditorFile {
  /** Unique path/name; shown (basename) on the tab and used as the model path. */
  path: string;
  /** Monaco language id. Inferred from the extension when omitted. */
  language?: string;
  /** File content. */
  value: string;
}

export interface CodeWorkspaceProps extends Omit<
  HTMLAttributes<HTMLDivElement>,
  "onChange" | "defaultValue"
> {
  /** Open files, one tab each. */
  files: EditorFile[];
  /** Controlled active file path. */
  activePath?: string;
  /** Initial active path for uncontrolled use. Defaults to the first file. */
  defaultActivePath?: string;
  /** Called when the active tab changes. */
  onActivePathChange?: (path: string) => void;
  /** Called on every edit with the file path + new content. */
  onFileChange?: (path: string, value: string) => void;
  /** Render all files read-only. */
  readOnly?: boolean;
  /** Workspace height. Number → px. Defaults to "100%". */
  height?: number | string;
}

const EXT_LANGUAGE: Record<string, string> = {
  ts: "typescript",
  tsx: "typescript",
  mts: "typescript",
  cts: "typescript",
  js: "javascript",
  jsx: "javascript",
  mjs: "javascript",
  cjs: "javascript",
  json: "json",
  css: "css",
  scss: "scss",
  less: "less",
  html: "html",
  md: "markdown",
  py: "python",
  sql: "sql",
  yml: "yaml",
  yaml: "yaml",
  xml: "xml",
  sh: "shell",
};

const basename = (path: string) => path.split("/").pop() || path;

function inferLanguage(file: EditorFile): string {
  if (file.language) return file.language;
  const ext = file.path.split(".").pop()?.toLowerCase() ?? "";
  return EXT_LANGUAGE[ext] ?? "plaintext";
}

/**
 * Multi-file editor shell: brand-ui `Tabs` for the file bar above a single
 * {@link CodeEditor} that swaps to the active file. This is the "reuse our
 * components for the chrome" surface — Tabs/Button are ours; the editing surface
 * is Monaco. Edits bubble through `onFileChange`.
 */
export const CodeWorkspace = forwardRef<HTMLDivElement, CodeWorkspaceProps>(function CodeWorkspace(
  {
    files,
    activePath,
    defaultActivePath,
    onActivePathChange,
    onFileChange,
    readOnly = false,
    height = "100%",
    className,
    style,
    ...props
  },
  ref,
) {
  const [internalActive, setInternalActive] = useState(defaultActivePath ?? files[0]?.path ?? "");
  const isControlled = activePath !== undefined;
  const requested = isControlled ? activePath : internalActive;
  const activeFile = files.find((f) => f.path === requested) ?? files[0];
  const active = activeFile?.path ?? "";

  const selectTab = useCallback(
    (path: string) => {
      if (!isControlled) setInternalActive(path);
      onActivePathChange?.(path);
    },
    [isControlled, onActivePathChange],
  );

  const resolvedStyle: CSSProperties = {
    height: typeof height === "number" ? `${height}px` : height,
    ...style,
  };

  return (
    <div
      ref={ref}
      className={cn(
        "flex flex-col overflow-hidden rounded-lg border border-border bg-surface",
        className,
      )}
      style={resolvedStyle}
      {...props}
    >
      <Tabs value={active} onValueChange={selectTab} className="flex min-h-0 flex-1 flex-col gap-0">
        <div className="flex items-center border-b border-border bg-surface">
          <TabsList className="h-9 flex-1 justify-start gap-0 rounded-none bg-transparent p-0">
            {files.map((file) => (
              <TabsTrigger
                key={file.path}
                value={file.path}
                className="h-9 rounded-none border-e border-border px-3 text-xs data-[state=active]:bg-background data-[state=active]:shadow-none"
              >
                {basename(file.path)}
              </TabsTrigger>
            ))}
          </TabsList>
          {activeFile ? <CopyButton value={activeFile.value} className="me-1.5" /> : null}
        </div>

        <div className="min-h-0 flex-1">
          {activeFile ? (
            <CodeEditor
              key={activeFile.path}
              path={activeFile.path}
              language={inferLanguage(activeFile)}
              value={activeFile.value}
              readOnly={readOnly}
              onChange={(next) => onFileChange?.(activeFile.path, next)}
              height="100%"
            />
          ) : null}
        </div>
      </Tabs>
    </div>
  );
});
