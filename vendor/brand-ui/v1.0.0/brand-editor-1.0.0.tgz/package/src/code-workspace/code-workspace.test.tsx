import { cleanup, render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

// CodeWorkspace renders real brand-ui Tabs over a CodeEditor; mock only Monaco.
const h = vi.hoisted(() => {
  const editor = {
    onDidChangeModelContent: vi.fn(() => ({ dispose: vi.fn() })),
    getValue: vi.fn(() => ""),
    setValue: vi.fn(),
    getModel: vi.fn(() => ({})),
    updateOptions: vi.fn(),
    getDomNode: vi.fn(() => null),
    dispose: vi.fn(),
  };
  return {
    editor,
    create: vi.fn(() => editor),
    createModel: vi.fn(() => ({ dispose: vi.fn() })),
  };
});

vi.mock("monaco-editor", () => ({
  editor: {
    create: h.create,
    createModel: h.createModel,
    setModelLanguage: vi.fn(),
    defineTheme: vi.fn(),
    setTheme: vi.fn(),
  },
  Uri: { parse: (s: string) => ({ toString: () => s }) },
}));

import { CodeWorkspace, type EditorFile } from "./code-workspace";

const FILES: EditorFile[] = [
  { path: "src/a.ts", value: "AAA" },
  { path: "b.json", value: "{}" },
];

beforeEach(() => vi.clearAllMocks());
afterEach(cleanup);

describe("CodeWorkspace", () => {
  it("renders a tab per file and opens the first file with its inferred language", () => {
    render(<CodeWorkspace files={FILES} />);
    expect(screen.getByRole("tab", { name: "a.ts" })).toBeInTheDocument();
    expect(screen.getByRole("tab", { name: "b.json" })).toBeInTheDocument();
    // First file active → model created with its content + language inferred from .ts
    expect(h.createModel).toHaveBeenCalledWith("AAA", "typescript", expect.anything());
  });

  it("switches the editor to the file whose tab is activated", async () => {
    const onActivePathChange = vi.fn();
    render(<CodeWorkspace files={FILES} onActivePathChange={onActivePathChange} />);
    await userEvent.click(screen.getByRole("tab", { name: "b.json" }));
    expect(onActivePathChange).toHaveBeenCalledWith("b.json");
    // Editor remounts for the JSON file → new model with json language.
    expect(h.createModel).toHaveBeenCalledWith("{}", "json", expect.anything());
  });
});
