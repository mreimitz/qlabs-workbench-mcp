import type { Meta, StoryObj } from "@storybook/react-vite";
import { expect, within } from "storybook/test";
import { useRef, useState } from "react";
import { MarkdownEditor, type MarkdownEditorHandle } from "./markdown-editor";

const meta = {
  title: "Editor/MarkdownEditor",
  component: MarkdownEditor,
  tags: ["autodocs"],
  parameters: {
    layout: "fullscreen",
    docs: {
      description: {
        component:
          "A headless Milkdown (ProseMirror) WYSIWYG markdown surface vendored onto " +
          "brand-ui. Companion to the Monaco `CodeEditor` (source) in the same package. " +
          "Theming is 100% semantic tokens, so it tracks all six themes via `data-theme`. " +
          "Depends on only `@milkdown/kit` — no Vue/Crepe.",
      },
    },
  },
} satisfies Meta<typeof MarkdownEditor>;

export default meta;
type Story = StoryObj<typeof meta>;

const SAMPLE = `# Customer Objective

Migrate **1,245 reports** to the new platform by Q3. Track scope, owners and risk.

## Checklist

- [x] Freeze scope
- [ ] Map data sources
- [ ] Pilot with finance

> Frozen scope candidates are the migration baseline.

| Phase  | Owner   | Status |
| ------ | ------- | ------ |
| Draft  | Manuel  | done   |
| Review | Team    | active |

Inline \`code\`, a [link](https://example.com), and a divider:

---

\`\`\`ts
export const scope = 1245;
\`\`\`
`;

export const Default: Story = {
  render: () => (
    <div className="mx-auto max-w-3xl p-6">
      <MarkdownEditor defaultValue={SAMPLE} />
    </div>
  ),
  play: async ({ canvasElement }) => {
    // Milkdown mounts asynchronously — wait for the rendered heading.
    const canvas = within(canvasElement);
    await expect(
      await canvas.findByText("Customer Objective", {}, { timeout: 8000 }),
    ).toBeVisible();
    // #21: the contenteditable role="textbox" surface must have an accessible name
    // (axe `aria-input-field-name`). Defaults to "Markdown editor".
    await expect(
      await canvas.findByRole("textbox", { name: "Markdown editor" }, { timeout: 8000 }),
    ).toBeVisible();
  },
};

export const Controlled: Story = {
  render: function ControlledStory() {
    const [value, setValue] = useState("# Type here\n\nEdits flow through `onChange`.");
    return (
      <div className="mx-auto flex max-w-3xl flex-col gap-3 p-6">
        <MarkdownEditor value={value} onChange={setValue} />
        <p className="text-xs text-muted-foreground">{value.length} characters</p>
      </div>
    );
  },
};

export const ReadOnly: Story = {
  name: "Read-only",
  render: () => (
    <div className="mx-auto max-w-3xl p-6">
      <MarkdownEditor defaultValue={SAMPLE} readOnly />
    </div>
  ),
};

const DIRECTIVES = `# Migration plan

:::card{title="Objective"}

Migrate the reporting estate to the new platform by Q3.

:::

:::callout{type="warning" title="At risk"}

Two upstream data sources are still un-mapped.

:::

::metric{label="Reports in scope" value="1,245" description="across 9 domains" delta="+12%"}

:::timeline

- (done) Freeze scope
- (active) Map data sources
- (pending) Pilot with finance

:::
`;

/**
 * The brand `:::` directives render as the REAL @brand components inside the editor
 * (a live `Card`, `Alert`, `MetricBlock`), with the card/callout title and the metric
 * label/value editable inline — not the old token-styled `toDOM` chrome. Switch the
 * Storybook theme to confirm they track all six themes.
 */
export const LiveDirectives: Story = {
  name: "Live directives (inline-editable)",
  render: () => (
    <div className="mx-auto max-w-3xl p-6">
      <MarkdownEditor defaultValue={DIRECTIVES} />
    </div>
  ),
  play: async ({ canvasElement }) => {
    const canvas = within(canvasElement);
    // The directive node-views expose their editable attributes as textboxes.
    await expect(
      await canvas.findByRole("textbox", { name: "Card title" }, { timeout: 8000 }),
    ).toBeVisible();
    await expect(canvas.getByRole("textbox", { name: "Metric value" })).toHaveTextContent("1,245");
    // The callout renders as a real Alert (role="alert").
    await expect(canvas.getByRole("alert")).toBeVisible();
  },
};

/**
 * Demonstrates `onEmbedAsset` — the paste/drop image-embed hook.
 *
 * The mock hook simulates a 600 ms upload delay and resolves with a data-URL
 * so no real server is needed. To exercise it manually:
 *   1. Copy an image file to your clipboard (or drag one onto the editor).
 *   2. Paste / drop into the editor surface.
 *   3. You will see the "Uploading…" chip appear, then the image render inline.
 *   4. The markdown output below shows `![filename](/demo/uploads/...)`.
 *
 * The error variant is toggled by the "Simulate failure" button — it wires a
 * hook that always rejects so you can observe the inline error chip + toast.
 *
 * Six-theme sweep: switch the Storybook theme (toolbar) to verify the upload
 * chip and error chip use only semantic tokens across qlik-bright/qlik-dark/
 * light/dark/blueprint/high-contrast.
 */
export const PasteEmbed: Story = {
  name: "Paste / drop image embed (onEmbedAsset)",
  render: function PasteEmbedStory() {
    const ref = useRef<MarkdownEditorHandle>(null);
    const [markdown, setMarkdown] = useState("# Image embed demo\n\nPaste or drop an image here.");
    const [simulateFailure, setSimulateFailure] = useState(false);
    const [lastPath, setLastPath] = useState<string | null>(null);

    const onEmbedAsset = async (file: File): Promise<string> => {
      if (simulateFailure) {
        await new Promise((_, reject) =>
          setTimeout(() => reject(new Error("Simulated upload failure")), 600),
        );
        throw new Error("Simulated upload failure");
      }
      // Simulate upload delay: read file as data-URL and return it.
      return new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => {
          const path = `/demo/uploads/${Date.now()}-${file.name}`;
          setLastPath(path);
          resolve(path);
        };
        reader.onerror = () => reject(new Error("FileReader error"));
        reader.readAsDataURL(file);
      });
    };

    return (
      <div className="mx-auto flex max-w-3xl flex-col gap-3 p-6">
        <div className="flex items-center gap-3">
          <label className="flex items-center gap-2 text-caption text-muted-foreground">
            <input
              type="checkbox"
              checked={simulateFailure}
              onChange={(e) => setSimulateFailure(e.target.checked)}
            />
            Simulate upload failure
          </label>
          {lastPath && (
            <span className="text-caption text-muted-foreground">
              Last resolved path: <code>{lastPath}</code>
            </span>
          )}
        </div>
        <MarkdownEditor
          ref={ref}
          value={markdown}
          onChange={setMarkdown}
          onEmbedAsset={onEmbedAsset}
          className="min-h-[200px]"
        />
        <details>
          <summary className="cursor-pointer text-caption text-muted-foreground">
            Serialized markdown
          </summary>
          <pre className="mt-1 overflow-auto rounded bg-muted p-3 text-caption">{markdown}</pre>
        </details>
      </div>
    );
  },
  play: async ({ canvasElement }) => {
    const canvas = within(canvasElement);
    // Wait for the editor to boot.
    await expect(
      await canvas.findByRole("textbox", { name: "Markdown editor" }, { timeout: 8000 }),
    ).toBeVisible();
    // The editor surface is ready; paste/drop interaction requires a real
    // ClipboardEvent with files, which Storybook interaction tests can't
    // synthesize reliably across browsers. Verify the surface is accessible.
    await expect(canvas.getByRole("textbox", { name: "Markdown editor" })).toBeVisible();
  },
};

/** GFM table seed for the EditableTable story. */
const TABLE_DOC = `# Project status

Click inside any table cell to reveal the **Table controls** toolbar below the
editor. Use it to add or remove rows and columns. Tab / Shift+Tab move between
cells. The table serializes back to lossless GFM markdown.

| Phase    | Owner   | Status  | Due     |
| -------- | ------- | ------- | ------- |
| Planning | Alice   | done    | 2024-Q1 |
| Build    | Bob     | active  | 2024-Q2 |
| Review   | Charlie | pending | 2024-Q3 |

Prose continues normally after the table.
`;

/**
 * Demonstrates the table node-view feature:
 *
 * - Click inside a table cell → the **Table controls** toolbar appears at the
 *   bottom of the editor surface.
 * - Toolbar buttons: Add row above/below, Delete row, Add col left/right,
 *   Delete column — all aria-labelled, keyboard-operable.
 * - Tab moves to the next cell; Shift+Tab to the previous.
 * - The serialized markdown (shown below the editor) stays lossless GFM.
 *
 * Six-theme sweep: switch the Storybook theme toolbar to verify the table
 * borders (`border-border-strong`), header tint (`bg-surface-muted`), and
 * toolbar chrome use only semantic tokens across all six themes.
 */
export const EditableTable: Story = {
  name: "Editable table (wysiwyg-tables)",
  render: function EditableTableStory() {
    const ref = useRef<MarkdownEditorHandle>(null);
    const [markdown, setMarkdown] = useState(TABLE_DOC);
    return (
      <div className="mx-auto flex max-w-3xl flex-col gap-3 p-6">
        <MarkdownEditor
          ref={ref}
          value={markdown}
          onChange={setMarkdown}
          className="min-h-[280px]"
        />
        <details>
          <summary className="cursor-pointer text-caption text-muted-foreground">
            Serialized markdown (GFM round-trip)
          </summary>
          <pre className="mt-1 overflow-auto rounded bg-muted p-3 text-caption">{markdown}</pre>
        </details>
      </div>
    );
  },
  play: async ({ canvasElement }) => {
    const canvas = within(canvasElement);
    // Wait for the editor to boot and the table to render.
    await expect(
      await canvas.findByRole("textbox", { name: "Markdown editor" }, { timeout: 8000 }),
    ).toBeVisible();
    // The GFM table must render as a real <table> element in the WYSIWYG.
    await expect(await canvas.findByRole("table", {}, { timeout: 8000 })).toBeVisible();
    // The table cells are accessible (role="cell" / "columnheader").
    const cells = canvas.getAllByRole("cell");
    expect(cells.length).toBeGreaterThan(0);
  },
};
