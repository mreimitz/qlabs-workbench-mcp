"use client";

/**
 * MarkdownEditor — a headless Milkdown (ProseMirror) WYSIWYG markdown surface,
 * vendored onto brand-ui. Companion to the Monaco-based CodeEditor: same package,
 * different engine (Monaco = source/diff; Milkdown = direct-manipulation markdown).
 *
 * - Engine dep: only `@milkdown/kit` (headless). React glue is vendored under
 *   ./milkdown-react so we never pull `@milkdown/react` → `@milkdown/crepe` → Vue.
 * - Theming: token-driven via markdown-editor.css (all six themes, no raw color).
 * - Controlled (`value` + `onChange`) or uncontrolled (`defaultValue`). Mirrors the
 *   platform: `isControlled = value !== undefined`; never flips between modes.
 * - StrictMode-safe (see markdown-editor.strictmode.test.tsx).
 * - The brand `:::` directives render as live @brand React components inside the
 *   editor (real <Card>/<Alert>/<MetricBlock>, with inline-editable titles +
 *   metric label/value) via @prosemirror-adapter/react — see directive-views.tsx.
 *   The shared remark pipeline keeps the editor and the Streamdown preview on one
 *   markdown dialect.
 */
import "@milkdown/kit/prose/view/style/prosemirror.css";
import "./markdown-editor.css";

import { Editor, defaultValueCtx, editorViewOptionsCtx, rootCtx } from "@milkdown/kit/core";
import { commonmark } from "@milkdown/kit/preset/commonmark";
import { gfm } from "@milkdown/kit/preset/gfm";
import { history } from "@milkdown/kit/plugin/history";
import { listener, listenerCtx } from "@milkdown/kit/plugin/listener";
import { getMarkdown, replaceAll } from "@milkdown/kit/utils";
import { cn } from "@brand/ui/lib/cn";
import {
  ProsemirrorAdapterProvider,
  useNodeViewFactory,
  usePluginViewFactory,
  useWidgetViewFactory,
} from "@prosemirror-adapter/react";
import { forwardRef, useEffect, useImperativeHandle, useRef, type HTMLAttributes } from "react";

import { calcProsePlugins } from "../calc-block/calc-editor-prose";
import type { CalcEditorHooks } from "../calc-block/types";
import { markdownScaleVars } from "../lib/markdown/markdown-scale";
import { directivePlugins } from "./directive-nodes";
import { directiveViewPlugins } from "./directive-views";
import { Milkdown, MilkdownProvider, useEditor, useInstance } from "./milkdown-react";
import { pasteEmbedPlugin, type EmbedAssetFn } from "./paste-embed";
import { brandSlashViewPlugins, type SlashCommand } from "./slash";
import { tableViewPlugins } from "./table-view";

/** Imperative handle exposed via `ref`. */
export interface MarkdownEditorHandle {
  /** Serialize the current document to a markdown string. */
  getMarkdown: () => string;
  /**
   * Serialize the current document, or `null` while the engine is still
   * booting. Used to capture the pre-edit normalization BASELINE for the
   * lossless-edit merge (WI-1) — unlike `getMarkdown` it never falls back to
   * the raw input, so a non-null result is always the editor's own output.
   */
  serialized: () => string | null;
}

export interface MarkdownEditorProps extends Omit<
  HTMLAttributes<HTMLDivElement>,
  "onChange" | "defaultValue"
> {
  /** Controlled markdown value. Pair with `onChange`. */
  value?: string;
  /** Initial markdown for uncontrolled use. */
  defaultValue?: string;
  /** Fires on every edit with the full markdown document. */
  onChange?: (markdown: string) => void;
  /** Render the editor read-only (still selectable, not editable). */
  readOnly?: boolean;
  /**
   * Accessible name for the editable surface. Milkdown/ProseMirror renders an ARIA
   * `textbox` (`contenteditable`); without a name, screen readers announce an
   * unlabeled field. Set onto the ProseMirror view's `attributes`. Default
   * `"Markdown editor"`.
   */
  ariaLabel?: string;
  /**
   * Enable the `/` command menu (insert brand `:::` directives + basic blocks
   * live at the caret). `true` (default) uses the built-in
   * {@link BRAND_SLASH_COMMANDS}; pass a `commands` array to extend/replace them,
   * or `false` to disable. The `trigger` defaults to `"/"`.
   */
  slashMenu?: boolean | { commands?: SlashCommand[]; trigger?: string };
  /**
   * Opt-in calc authoring inside ```calc fences (off by default). Supply the
   * consumer's hooks — `tokenize` (highlight), `evaluate` (result inlays), and/or
   * `complete` (autocomplete; Monaco surface). The library DECORATES, the consumer
   * COMPUTES — no calc engine is bundled. Mirrors `MarkdownPreview`'s `evaluate`.
   */
  calc?: CalcEditorHooks;
  /**
   * Host-provided callback for image paste/drop embedding.
   *
   * When set, the editor intercepts paste and drop events that contain image
   * files, shows an inline "uploading…" placeholder, calls this function with
   * the `File`, and on resolve inserts `![filename](returnedPath)` in the
   * document. On reject the placeholder is removed and an inline error chip
   * (+ toast) is shown — the document never contains a broken image.
   *
   * If not set, the editor's default paste/drop behavior is unchanged.
   *
   * The library NEVER stores assets — all persistence is the host's responsibility.
   */
  onEmbedAsset?: EmbedAssetFn;
}

export type { EmbedAssetFn };

interface ViewProps {
  initialValue: string;
  value?: string;
  onChange?: (markdown: string) => void;
  readOnly: boolean;
  ariaLabel: string;
  slashMenu: boolean | { commands?: SlashCommand[]; trigger?: string };
  calc?: CalcEditorHooks;
  onEmbedAsset?: EmbedAssetFn;
}

const MarkdownEditorView = forwardRef<MarkdownEditorHandle, ViewProps>(function MarkdownEditorView(
  { initialValue, value, onChange, readOnly, ariaLabel, slashMenu, calc, onEmbedAsset },
  ref,
) {
  // Latest onChange via a ref so the create effect can run once per `readOnly`.
  const onChangeRef = useRef(onChange);
  onChangeRef.current = onChange;
  // Tracks the editor's current markdown — both the "preserve across recreate"
  // value and the echo-guard for controlled `value` syncing.
  const lastMarkdown = useRef(initialValue);

  // Renders the brand `:::` directives as live @brand React components inside the
  // editor (must run under <ProsemirrorAdapterProvider>). The factory is stable.
  const nodeViewFactory = useNodeViewFactory();
  // The widget factory backs the `/` command menu (rendered as a ProseMirror
  // widget at the caret). Same adapter, also stable.
  const widgetViewFactory = useWidgetViewFactory();
  // The plugin-view factory mounts the table controls toolbar as a ProseMirror
  // plugin view (outside contentEditable, no focus conflicts).
  const pluginViewFactory = usePluginViewFactory();

  // Resolve the slash config through a ref so a fresh `commands` array identity
  // each render never rebuilds the editor — only enabling/disabling does.
  const slashEnabled = slashMenu !== false;
  const slashConfigRef = useRef<{ commands?: SlashCommand[]; trigger?: string }>({});
  slashConfigRef.current = typeof slashMenu === "object" ? slashMenu : {};

  // Calc authoring hooks read through a ref — like the slash config, a fresh
  // `calc` object identity each render must NOT rebuild the editor; only
  // toggling the feature on/off does (the plugin reads the latest hooks lazily).
  const calcEnabled = calc != null;
  const calcRef = useRef<CalcEditorHooks | undefined>(calc);
  calcRef.current = calc;

  // Keep onEmbedAsset in a ref so the editor factory captures it by reference —
  // a new function identity each render never causes an editor rebuild.
  const onEmbedAssetRef = useRef(onEmbedAsset);
  onEmbedAssetRef.current = onEmbedAsset;

  useEditor(
    (root) => {
      // Build the paste-embed plugin with an indirection through the ref so the
      // plugin always calls the latest host callback without rebuilding.
      const embedPlugin = pasteEmbedPlugin(
        onEmbedAssetRef.current ? (file: File) => onEmbedAssetRef.current!(file) : undefined,
      );

      let editor = Editor.make()
        .config((ctx) => {
          ctx.set(rootCtx, root);
          ctx.set(defaultValueCtx, lastMarkdown.current);
          ctx.update(editorViewOptionsCtx, (prev) => ({
            ...prev,
            editable: () => !readOnly,
            // Name the ProseMirror `role="textbox"` surface so AT announces it.
            // Spread prev.attributes so we never clobber Milkdown's own view attrs.
            attributes: { ...prev.attributes, "aria-label": ariaLabel },
          }));
          ctx.get(listenerCtx).markdownUpdated((_, markdown) => {
            lastMarkdown.current = markdown;
            onChangeRef.current?.(markdown);
          });
        })
        .use(commonmark)
        .use(gfm)
        .use(tableViewPlugins(pluginViewFactory))
        .use(history)
        .use(listener)
        .use(directivePlugins)
        .use(directiveViewPlugins(nodeViewFactory))
        .use(embedPlugin);
      if (slashEnabled) {
        editor = editor.use(brandSlashViewPlugins(widgetViewFactory, slashConfigRef.current));
      }
      if (calcEnabled) {
        editor = editor.use(calcProsePlugins(() => calcRef.current));
      }
      return editor;
    },
    [readOnly, ariaLabel, slashEnabled, calcEnabled],
  );

  const [loading, getInstance] = useInstance();

  // Controlled sync: push external `value` into the editor only when it diverges
  // from what the editor last emitted (avoids clobbering on our own echo).
  useEffect(() => {
    if (loading || value === undefined) return;
    if (value === lastMarkdown.current) return;
    const editor = getInstance();
    if (!editor) return;
    lastMarkdown.current = value;
    editor.action(replaceAll(value));
  }, [loading, value, getInstance]);

  useImperativeHandle(
    ref,
    () => ({
      getMarkdown: () => getInstance()?.action(getMarkdown()) ?? lastMarkdown.current,
      serialized: () => getInstance()?.action(getMarkdown()) ?? null,
    }),
    [getInstance],
  );

  return <Milkdown />;
});

export const MarkdownEditor = forwardRef<MarkdownEditorHandle, MarkdownEditorProps>(
  function MarkdownEditor(
    {
      value,
      defaultValue,
      onChange,
      readOnly = false,
      ariaLabel = "Markdown editor",
      slashMenu = true,
      calc,
      onEmbedAsset,
      className,
      style,
      ...props
    },
    ref,
  ) {
    // Capture the initial value once; later `value` changes flow through the
    // controlled-sync effect, not a remount.
    const initialValue = useRef(value ?? defaultValue ?? "").current;

    return (
      <div
        data-testid="markdown-editor"
        className={cn(
          "milkdown-host overflow-auto rounded-md border border-border bg-background text-foreground focus-within:ring-2 focus-within:ring-ring",
          className,
        )}
        // Publish the shared markdown scale as CSS vars the editor CSS reads, so the
        // WYSIWYG headings/measure match the preview (single source of truth, #18).
        style={{ ...markdownScaleVars(), ...style }}
        {...props}
      >
        <MilkdownProvider>
          <ProsemirrorAdapterProvider>
            <MarkdownEditorView
              ref={ref}
              initialValue={initialValue}
              value={value}
              onChange={onChange}
              readOnly={readOnly}
              ariaLabel={ariaLabel}
              slashMenu={slashMenu}
              calc={calc}
              onEmbedAsset={onEmbedAsset}
            />
          </ProsemirrorAdapterProvider>
        </MilkdownProvider>
      </div>
    );
  },
);
