/**
 * Unit tests for the slash-command registry — pure data: shape, grouping, and the
 * query filter. (The `run` insertion path is covered against a real editor in
 * insert-directive.test.ts.)
 */
import { describe, expect, test } from "vitest";

import {
  BRAND_SLASH_COMMANDS,
  filterSlashCommands,
  groupSlashCommands,
} from "./brand-slash-commands";

describe("BRAND_SLASH_COMMANDS shape", () => {
  test("every command has a unique id, a label, a group, and a run", () => {
    const ids = new Set<string>();
    for (const c of BRAND_SLASH_COMMANDS) {
      expect(typeof c.id).toBe("string");
      expect(c.id.length).toBeGreaterThan(0);
      expect(ids.has(c.id)).toBe(false);
      ids.add(c.id);
      expect(typeof c.label).toBe("string");
      expect(c.label.length).toBeGreaterThan(0);
      expect(typeof c.group).toBe("string");
      expect(typeof c.run).toBe("function");
    }
  });

  test("covers the four brand directives + the basic blocks", () => {
    const labels = BRAND_SLASH_COMMANDS.map((c) => c.label);
    expect(labels).toEqual(expect.arrayContaining(["Card", "Callout", "Metric", "Timeline"]));
    expect(labels).toEqual(
      expect.arrayContaining([
        "Heading",
        "Bullet list",
        "Numbered list",
        "Quote",
        "Code block",
        "Divider",
      ]),
    );
  });

  test("brand blocks are in the 'Brand blocks' group, basics in 'Basic'", () => {
    const brand = BRAND_SLASH_COMMANDS.filter((c) => c.group === "Brand blocks");
    const basic = BRAND_SLASH_COMMANDS.filter((c) => c.group === "Basic");
    expect(brand.map((c) => c.label)).toEqual([
      "Card",
      "Callout",
      "Metric",
      "Timeline",
      "Iterate",
      "Pivot",
      "Calc",
    ]);
    expect(basic.length).toBe(6);
  });

  test("the /calc command (#220) is registered and inserts a calc fence", () => {
    const calc = BRAND_SLASH_COMMANDS.find((c) => c.id === "brand-calc");
    expect(calc).toBeDefined();
    expect(calc?.label).toBe("Calc");
    expect(calc?.keywords).toEqual(expect.arrayContaining(["calc", "math", "formula"]));
  });
});

describe("filterSlashCommands", () => {
  test("an empty query returns the full list in order", () => {
    expect(filterSlashCommands(BRAND_SLASH_COMMANDS, "")).toBe(BRAND_SLASH_COMMANDS);
    expect(filterSlashCommands(BRAND_SLASH_COMMANDS, "   ")).toBe(BRAND_SLASH_COMMANDS);
  });

  test("matches on the label (case-insensitive substring)", () => {
    const r = filterSlashCommands(BRAND_SLASH_COMMANDS, "ca");
    const labels = r.map((c) => c.label);
    // "ca" matches Card + Callout (label) and others via keywords.
    expect(labels).toEqual(expect.arrayContaining(["Card", "Callout"]));
  });

  test("matches on keywords too (e.g. 'kpi' → Metric)", () => {
    const r = filterSlashCommands(BRAND_SLASH_COMMANDS, "kpi");
    expect(r.map((c) => c.label)).toContain("Metric");
  });

  test("matches 'alert' → Callout via keyword", () => {
    const r = filterSlashCommands(BRAND_SLASH_COMMANDS, "alert");
    expect(r.map((c) => c.label)).toContain("Callout");
  });

  test("a no-match query returns an empty list", () => {
    expect(filterSlashCommands(BRAND_SLASH_COMMANDS, "zzzznotacommand")).toHaveLength(0);
  });
});

describe("groupSlashCommands", () => {
  test("preserves first-seen group order and keeps every command", () => {
    const grouped = groupSlashCommands(BRAND_SLASH_COMMANDS);
    expect(grouped.map((g) => g.group)).toEqual(["Brand blocks", "Basic"]);
    const total = grouped.reduce((n, g) => n + g.commands.length, 0);
    expect(total).toBe(BRAND_SLASH_COMMANDS.length);
  });

  test("a filtered list groups correctly (only matching groups appear)", () => {
    const filtered = filterSlashCommands(BRAND_SLASH_COMMANDS, "card");
    const grouped = groupSlashCommands(filtered);
    // "card" only matches a brand block → only the Brand blocks group shows.
    expect(grouped.map((g) => g.group)).toEqual(["Brand blocks"]);
  });
});
