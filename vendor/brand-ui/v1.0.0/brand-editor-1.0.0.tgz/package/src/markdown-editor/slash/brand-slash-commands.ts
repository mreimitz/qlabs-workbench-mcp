/**
 * The brand slash-command registry — pure, typed, tree-shakeable data.
 *
 * Each command is a label + group + match keywords + an icon + a `run` that
 * inserts the corresponding block at the caret. `run` is given a
 * {@link SlashInsertContext} (the Milkdown `Ctx` + the active `/query` range);
 * brand directives delegate to `resolveBrandInsert`, basic blocks to
 * `resolveBasicInsert` — so the SAME registry drives the menu and any
 * programmatic insert, and the load-bearing insertion logic stays in
 * `insert-directive.ts` (unit-tested there).
 *
 * Defaults: card · callout · metric · timeline ("Brand blocks") +
 * heading · bullet-list · ordered-list · quote · code · divider ("Basic").
 * Consumers can extend or replace the list via the `slashMenu` prop.
 */
import type { Ctx } from "@milkdown/kit/ctx";
import {
  Calculator,
  Grid3x3,
  Heading2,
  List,
  ListOrdered,
  Minus,
  Quote,
  Repeat2,
  SquareCode,
  type LucideIcon,
} from "lucide-react";
import { createElement, type ReactNode } from "react";

import {
  resolveBasicInsert,
  resolveBrandInsert,
  resolveCalcInsert,
  type InsertableDirective,
  type SlashRange,
} from "./insert-directive";

/** The native (non-directive) blocks the slash menu can insert. */
export type BasicBlockId =
  | "heading"
  | "bullet-list"
  | "ordered-list"
  | "quote"
  | "code"
  | "divider";

/**
 * Context handed to a {@link SlashCommand.run}. `ctx` is the live Milkdown editor
 * context; `range` is the `[from, to)` document range of the typed trigger +
 * query (so the command replaces it), or `null` to insert at the caret.
 */
export interface SlashInsertContext {
  ctx: Ctx;
  range: SlashRange | null;
}

/** One entry in the slash menu. Pure data + an insertion `run`. */
export interface SlashCommand {
  /** Stable id (used as the React key + `aria-activedescendant` target). */
  id: string;
  /** Visible label, e.g. "Card". */
  label: string;
  /** Grouping header, e.g. "Brand blocks" | "Basic". */
  group?: string;
  /** A short description shown under the label. */
  description?: string;
  /** Extra fuzzy-match aids beyond the label (matched case-insensitively). */
  keywords?: string[];
  /** Leading icon (a Lucide glyph or any node). */
  icon?: ReactNode;
  /** Insert the block at the caret. */
  run: (ctx: SlashInsertContext) => void;
}

/** Build a Lucide icon element at the menu's standard size. */
function glyph(icon: LucideIcon): ReactNode {
  return createElement(icon, { className: "size-4", "aria-hidden": "true" });
}

/** A brand-directive command (card/callout/metric/timeline). */
function brandCommand(
  name: InsertableDirective,
  label: string,
  description: string,
  keywords: string[],
  icon: ReactNode,
): SlashCommand {
  return {
    id: `brand-${name}`,
    label,
    group: "Brand blocks",
    description,
    keywords,
    icon,
    run: ({ ctx, range }) => resolveBrandInsert(ctx, name, range),
  };
}

/** A basic native-block command. */
function basicCommand(
  id: BasicBlockId,
  label: string,
  description: string,
  keywords: string[],
  icon: LucideIcon,
): SlashCommand {
  return {
    id: `basic-${id}`,
    label,
    group: "Basic",
    description,
    keywords,
    icon: glyph(icon),
    run: ({ ctx, range }) => resolveBasicInsert(ctx, id, range),
  };
}

/**
 * The default command list. Brand blocks first (the wedge), then the basics.
 * The brand-block icons reuse the `data-brand-directive` chrome look via Lucide
 * stand-ins (the editor renders the real component once inserted).
 */
export const BRAND_SLASH_COMMANDS: SlashCommand[] = [
  brandCommand(
    "card",
    "Card",
    "A titled content card",
    ["card", "panel", "box", "section"],
    glyph(SquareCode),
  ),
  brandCommand(
    "callout",
    "Callout",
    "A highlighted note / alert",
    ["callout", "alert", "note", "info", "warning", "tip"],
    glyph(Quote),
  ),
  brandCommand(
    "metric",
    "Metric",
    "A single KPI value",
    ["metric", "kpi", "stat", "number", "value"],
    glyph(Minus),
  ),
  brandCommand(
    "timeline",
    "Timeline",
    "A list of steps with status",
    ["timeline", "steps", "milestones", "roadmap", "progress"],
    glyph(List),
  ),
  brandCommand(
    "iterate",
    "Iterate",
    "Repeat a template per data row",
    ["iterate", "repeat", "loop", "for-each", "foreach", "map", "list", "template"],
    glyph(Repeat2),
  ),
  brandCommand(
    "pivot",
    "Pivot",
    "A row × column cross-tab",
    ["pivot", "matrix", "cross-tab", "crosstab", "table", "grid"],
    glyph(Grid3x3),
  ),
  {
    // Inserts a ```calc fence (not a `:::` directive), so it runs its own command
    // rather than `resolveBrandInsert`. Highlight + result inlays come from the
    // editor's calc hooks; the fence is harmless when none are wired.
    id: "brand-calc",
    label: "Calc",
    group: "Brand blocks",
    description: "A live calculation block",
    keywords: ["calc", "calculation", "math", "formula", "sum", "ledger", "budget"],
    icon: glyph(Calculator),
    run: ({ ctx, range }) => resolveCalcInsert(ctx, range),
  },
  basicCommand("heading", "Heading", "Section heading", ["heading", "title", "h2"], Heading2),
  basicCommand(
    "bullet-list",
    "Bullet list",
    "An unordered list",
    ["bullet", "list", "unordered", "ul"],
    List,
  ),
  basicCommand(
    "ordered-list",
    "Numbered list",
    "An ordered list",
    ["numbered", "ordered", "list", "ol"],
    ListOrdered,
  ),
  basicCommand("quote", "Quote", "A block quotation", ["quote", "blockquote", "citation"], Quote),
  basicCommand(
    "code",
    "Code block",
    "A fenced code block",
    ["code", "snippet", "pre", "fence"],
    SquareCode,
  ),
  basicCommand(
    "divider",
    "Divider",
    "A horizontal rule",
    ["divider", "rule", "hr", "separator"],
    Minus,
  ),
];

/**
 * Filter a command list by a query (case-insensitive substring over label +
 * keywords). An empty query returns the full list (in registry order).
 */
export function filterSlashCommands(commands: SlashCommand[], query: string): SlashCommand[] {
  const q = query.trim().toLowerCase();
  if (!q) return commands;
  return commands.filter((c) => {
    if (c.label.toLowerCase().includes(q)) return true;
    return (c.keywords ?? []).some((k) => k.toLowerCase().includes(q));
  });
}

/** Preserve registry order while grouping; used by the menu to render headers. */
export function groupSlashCommands(
  commands: SlashCommand[],
): { group: string; commands: SlashCommand[] }[] {
  const order: string[] = [];
  const byGroup = new Map<string, SlashCommand[]>();
  for (const c of commands) {
    const g = c.group ?? "Other";
    if (!byGroup.has(g)) {
      byGroup.set(g, []);
      order.push(g);
    }
    byGroup.get(g)!.push(c);
  }
  return order.map((group) => ({ group, commands: byGroup.get(group)! }));
}
