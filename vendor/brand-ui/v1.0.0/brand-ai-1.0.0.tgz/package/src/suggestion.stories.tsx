import type { Meta, StoryObj } from "@storybook/react-vite";
import { Suggestion, Suggestions } from "./suggestion";
const meta = {
  title: "AI/Suggestion",
  component: Suggestions,
  parameters: { layout: "padded" },
} satisfies Meta<typeof Suggestions>;
export default meta;
type Story = StoryObj<typeof meta>;
// Default = the soft tinted pill (#194): borderless `bg-secondary rounded-full`.
export const Default: Story = {
  render: () => (
    <Suggestions>
      {["Summarize the deploys", "Explain the billing error", "Write a regression test"].map(
        (s) => (
          <Suggestion key={s} suggestion={s} onClick={() => {}} />
        ),
      )}
    </Suggestions>
  ),
};
// A caller can still opt into an outlined chip; reach for the quiet
// `outline-subtle` hairline, not the strong form-field `outline`.
export const OutlineSubtle: Story = {
  render: () => (
    <Suggestions>
      {["Compare to last quarter", "Draft the follow-up email"].map((s) => (
        <Suggestion key={s} suggestion={s} variant="outline-subtle" onClick={() => {}} />
      ))}
    </Suggestions>
  ),
};
