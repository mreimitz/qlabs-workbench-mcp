import { describe, expect, it, vi } from "vitest";
import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { Suggestion } from "./suggestion";

describe("Suggestion", () => {
  it("renders the suggestion text and fires onClick with it", async () => {
    const onClick = vi.fn();
    render(<Suggestion suggestion="Summarize the deploy log" onClick={onClick} />);

    const button = screen.getByRole("button", { name: "Summarize the deploy log" });
    expect(button).toBeInTheDocument();

    await userEvent.click(button);
    expect(onClick).toHaveBeenCalledWith("Summarize the deploy log");
  });

  // #194 (research 02 §3a BTN-2): the default is the soft tinted pill —
  // borderless `bg-secondary` + `rounded-full` — never the strong `--input`
  // outline. A caller-supplied variant still wins.
  it("defaults to the borderless secondary pill", () => {
    render(<Suggestion suggestion="Soft pill" />);
    const button = screen.getByRole("button", { name: "Soft pill" });
    const classes = button.className.split(" ");
    expect(classes).toContain("bg-secondary");
    expect(classes).toContain("rounded-full");
    expect(classes).not.toContain("border");
    expect(classes).not.toContain("border-input");
  });
});
