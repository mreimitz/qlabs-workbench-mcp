"use client";

import type { ReactNode } from "react";
import { cn } from "@brand/ui/lib/cn";

export interface ChatShellProps {
  /** Scrollable transcript — typically a <Conversation>. */
  children: ReactNode;
  /** Sticky composer — typically a <PromptInput>. */
  composer?: ReactNode;
  /** Optional header row (title, model picker, actions). */
  header?: ReactNode;
  /** Optional right-side context rail (sources, files, memory). */
  aside?: ReactNode;
  className?: string;
}

/**
 * Layout shell for an AI chat built from the AI Elements: a header, a scrollable
 * transcript (give it a <Conversation>, which is `flex-1`), a sticky composer
 * (a <PromptInput>), and an optional context rail. Fills its parent's height.
 */
export function ChatShell({ children, composer, header, aside, className }: ChatShellProps) {
  return (
    <div
      className={cn(
        "flex h-full min-h-0 w-full overflow-hidden rounded-xl border bg-background",
        className,
      )}
    >
      <div className="flex min-h-0 min-w-0 flex-1 flex-col">
        {header ? (
          <div className="flex h-12 shrink-0 items-center border-b px-4">{header}</div>
        ) : null}
        <div className="flex min-h-0 flex-1 flex-col">{children}</div>
        {composer ? <div className="shrink-0 border-t p-3">{composer}</div> : null}
      </div>
      {aside ? <div className="hidden w-80 shrink-0 border-s lg:block">{aside}</div> : null}
    </div>
  );
}
