import { describe, expect, it } from "vitest";
import { render, screen } from "@testing-library/react";
import { CTASection } from "./cta-section";

describe("CTASection", () => {
  it("renders the title", () => {
    render(<CTASection title="Start building today" animate={false} />);
    expect(screen.getByText("Start building today")).toBeInTheDocument();
  });

  it("renders the title as an h2 heading", () => {
    render(<CTASection title="Get started for free" animate={false} />);
    expect(
      screen.getByRole("heading", { level: 2, name: "Get started for free" }),
    ).toBeInTheDocument();
  });

  it("renders description when provided", () => {
    render(<CTASection title="Ready?" description="No credit card required" animate={false} />);
    expect(screen.getByText("No credit card required")).toBeInTheDocument();
  });

  it("renders actions when provided", () => {
    render(<CTASection title="Join us" actions={<button>Sign up free</button>} animate={false} />);
    expect(screen.getByRole("button", { name: "Sign up free" })).toBeInTheDocument();
  });

  it("renders a section element in the document", () => {
    const { container } = render(<CTASection title="Call to action" animate={false} />);
    expect(container.querySelector("section")).toBeInTheDocument();
  });
});
