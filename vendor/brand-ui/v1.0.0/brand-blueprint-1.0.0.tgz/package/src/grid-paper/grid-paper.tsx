import { forwardRef, type CSSProperties, type HTMLAttributes } from "react";
import { cn } from "@brand/ui/lib/cn";

export type GridPaperVariant = "lines" | "dots" | "crosshatch" | "hatch";
export type GridPaperSize = "sm" | "md" | "lg";

export interface GridPaperProps extends HTMLAttributes<HTMLDivElement> {
  /** Ruling style. @default "lines" */
  variant?: GridPaperVariant;
  /** Minor cell pitch. @default "md" */
  size?: GridPaperSize;
  /** Fade the ruling out toward the edges with a soft radial mask. */
  fade?: boolean;
}

const MINOR: Record<GridPaperSize, number> = { sm: 6, md: 8, lg: 12 };

/** Build a token-driven background-image (colors are CSS vars — no raw hex). */
function ruling(variant: GridPaperVariant, minor: number): string {
  const line = "var(--grid-line)";
  const major = "var(--grid-line-major)";
  const big = minor * 10;
  switch (variant) {
    case "dots":
      return `radial-gradient(${line} 1px, transparent 1.5px)`;
    case "hatch":
      return `repeating-linear-gradient(45deg, ${major} 0, ${major} 1px, transparent 1px, transparent ${minor}px)`;
    case "crosshatch":
      return [
        `repeating-linear-gradient(45deg, ${line} 0, ${line} 1px, transparent 1px, transparent ${minor}px)`,
        `repeating-linear-gradient(-45deg, ${line} 0, ${line} 1px, transparent 1px, transparent ${minor}px)`,
      ].join(", ");
    case "lines":
    default:
      return [
        `repeating-linear-gradient(to right, ${major} 0, ${major} 1px, transparent 1px, transparent ${big}px)`,
        `repeating-linear-gradient(to bottom, ${major} 0, ${major} 1px, transparent 1px, transparent ${big}px)`,
        `repeating-linear-gradient(to right, ${line} 0, ${line} 1px, transparent 1px, transparent ${minor}px)`,
        `repeating-linear-gradient(to bottom, ${line} 0, ${line} 1px, transparent 1px, transparent ${minor}px)`,
      ].join(", ");
  }
}

const FADE = "radial-gradient(ellipse at center, black 55%, transparent 100%)";

/**
 * Graph-paper ground. A token-driven ruled (or dotted / cross-hatched) surface
 * that everything else is drawn on. Decorative when empty (aria-hidden); when
 * given children it acts as a layout ground and they render above the ruling.
 */
export const GridPaper = forwardRef<HTMLDivElement, GridPaperProps>(function GridPaper(
  { variant = "lines", size = "md", fade = false, className, style, children, ...props },
  ref,
) {
  const minor = MINOR[size];
  const mergedStyle: CSSProperties = {
    backgroundColor: "var(--canvas)",
    backgroundImage: ruling(variant, minor),
    ...(variant === "dots" ? { backgroundSize: `${minor}px ${minor}px` } : null),
    ...(fade ? { maskImage: FADE, WebkitMaskImage: FADE } : null),
    ...style,
  };
  return (
    <div
      ref={ref}
      data-slot="grid-paper"
      aria-hidden={children ? undefined : true}
      className={cn("relative", className)}
      style={mergedStyle}
      {...props}
    >
      {children}
    </div>
  );
});
