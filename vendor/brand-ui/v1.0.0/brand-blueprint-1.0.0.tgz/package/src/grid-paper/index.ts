export {
  GridPaper,
  type GridPaperProps,
  type GridPaperVariant,
  type GridPaperSize,
} from "./grid-paper";
