import type { Meta, StoryObj } from "@storybook/react-vite";
import { Bold, BookOpen, Italic, PencilLine, Underline } from "lucide-react";
import { ToggleGroup, ToggleGroupItem } from "./toggle-group";
const meta = {
  title: "Forms/ToggleGroup",
  component: ToggleGroup,
  tags: ["autodocs"],
} satisfies Meta<typeof ToggleGroup>;
export default meta;
type Story = StoryObj<typeof meta>;
export const Default: Story = {
  render: () => (
    <ToggleGroup type="multiple" variant="outline">
      <ToggleGroupItem value="bold" aria-label="Bold">
        <Bold />
      </ToggleGroupItem>
      <ToggleGroupItem value="italic" aria-label="Italic">
        <Italic />
      </ToggleGroupItem>
      <ToggleGroupItem value="underline" aria-label="Underline">
        <Underline />
      </ToggleGroupItem>
    </ToggleGroup>
  ),
};

/**
 * Segmented mode switch — a single-select group on a recessed `bg-muted`
 * track with a raised elevated active segment: the same elevation grammar
 * as Tabs. Use it for exclusive view/mode controls (Read ↔ Write, editor
 * source/split/wysiwyg) instead of the bordered toggle variants.
 */
export const Segmented: Story = {
  render: () => (
    <ToggleGroup
      type="single"
      variant="segmented"
      size="sm"
      defaultValue="read"
      aria-label="Document mode"
    >
      <ToggleGroupItem value="read" aria-label="Read">
        <BookOpen /> Read
      </ToggleGroupItem>
      <ToggleGroupItem value="write" aria-label="Write">
        <PencilLine /> Write
      </ToggleGroupItem>
    </ToggleGroup>
  ),
};
