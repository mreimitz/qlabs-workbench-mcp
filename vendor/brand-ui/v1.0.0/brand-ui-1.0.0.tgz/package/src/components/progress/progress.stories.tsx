import type { Meta, StoryObj } from "@storybook/react-vite";
import { Progress } from "./progress";
const meta = { title: "Display/Progress", component: Progress, tags: ["autodocs"] } satisfies Meta<
  typeof Progress
>;
export default meta;
type Story = StoryObj<typeof meta>;
export const Default: Story = { render: () => <Progress value={62} className="w-64" /> };
