"use client";

/**
 * RevisionTimeline — a presentational git-history timeline.
 *
 * Renders revisions (newest-first) with:
 *   - Day grouping by calendar day from `timestamp`
 *   - An SVG lane gutter for branch-graph lanes and merge joins
 *   - Churn indicators (+additions / -deletions)
 *   - A selection rail (controlled + uncontrolled)
 *
 * The APP computes the graph layout (lane indices, edges). This component
 * only renders what it receives. Heavy graph-math stays out.
 *
 * GATE NOTES:
 *   - No identifier starting with `Timeline` (timeline-fork class 1).
 *   - Lanes/connectors drawn with SVG <line> / <path>, NOT `absolute w-px`
 *     hairlines (timeline-fork class 2 avoidance).
 */

import {
  createContext,
  forwardRef,
  use,
  useCallback,
  useMemo,
  useState,
  type HTMLAttributes,
} from "react";
import { cva, type VariantProps } from "class-variance-authority";
import { GitCommitHorizontal, GitMerge, Plus, Minus } from "lucide-react";
import { cn } from "../../lib/cn";

// ─── Public data types ────────────────────────────────────────────────────────

/**
 * A single revision entry. The APP assigns `lane` (0-based column index),
 * computes `additions`/`deletions`, and orders revisions newest-first.
 */
export interface Revision {
  /** Unique identifier — used for selection + edge references. */
  id: string;
  /** Commit message (may be long; the component truncates). */
  message: string;
  /** Display name of the commit author. */
  author?: string;
  /** Avatar image URL for the author. */
  authorAvatar?: string;
  /** When the commit was authored. Accepts Date, ISO string, or epoch ms. */
  timestamp: Date | string | number;
  /** Short commit hash (e.g. "a1b2c3d"). */
  shortSha?: string;
  /** Lines added (churn indicator). */
  additions?: number;
  /** Lines deleted (churn indicator). */
  deletions?: number;
  /**
   * Column index assigned by the app (0-based). Lane 0 = main branch (leftmost).
   * Used to position the node dot and draw the lane spine in the SVG gutter.
   */
  lane: number;
  /** Branch or tag labels rendered as chips on this revision. */
  refs?: string[];
}

/**
 * A parent link between two revisions, for the lane graph.
 * Used to draw merge joins (curves / angled lines) in the SVG gutter.
 */
export interface RevisionEdge {
  /** Id of the child revision (newer, higher in the list). */
  from: string;
  /** Id of the parent revision (older, lower in the list). */
  to: string;
}

// ─── Variants ────────────────────────────────────────────────────────────────

/** Visual density variants for the timeline. */
export const revisionTimelineVariants = cva("flex flex-col", {
  variants: {
    density: {
      comfortable: "gap-0",
      compact: "gap-0",
    },
  },
  defaultVariants: { density: "comfortable" },
});

export type RevisionTimelineDensity = NonNullable<
  VariantProps<typeof revisionTimelineVariants>["density"]
>;

// ─── Lane geometry helpers ────────────────────────────────────────────────────

/**
 * The number of chart palette colors. Lane index is wrapped modulo this count,
 * so `lane % LANE_PALETTE_SIZE` never exceeds the token range 1-5.
 */
const LANE_PALETTE_SIZE = 5;

/** Lane index → CSS token string (`var(--chart-1)` … `var(--chart-5)`). */
export function laneColor(lane: number): string {
  return `var(--chart-${(lane % LANE_PALETTE_SIZE) + 1})`;
}

/** Width of one lane column in the SVG gutter (px). */
const LANE_W = 16;
/** Row height in the SVG gutter — must match the rendered row height. */
const ROW_H_COMFORTABLE = 48;
const ROW_H_COMPACT = 36;
/**
 * Fixed height of a day-group header. MUST match the rendered `DayHeader`'s box
 * so the SVG gutter's node dots stay aligned with their list rows once a header
 * inserts vertical space between groups (otherwise the graph desyncs from the
 * rows — the gutter and the list share one coordinate space).
 */
const DAY_HEADER_H = 32;
/** Radius of the node dot. */
const NODE_R = 4;

/** X centre of a lane column in the SVG. */
function laneX(lane: number): number {
  return lane * LANE_W + LANE_W / 2;
}

// ─── Context ─────────────────────────────────────────────────────────────────

interface RevisionTimelineCtx {
  selectedId: string | undefined;
  onSelect: (id: string) => void;
}

const RevisionTimelineContext = createContext<RevisionTimelineCtx | null>(null);

function useRevisionTimelineCtx(): RevisionTimelineCtx {
  const ctx = use(RevisionTimelineContext);
  if (!ctx) throw new Error("RevisionTimeline sub-parts must be inside <RevisionTimeline>");
  return ctx;
}

// ─── SVG lane gutter ─────────────────────────────────────────────────────────

interface LaneGutterProps {
  revisions: Revision[];
  edges: RevisionEdge[];
  /**
   * Map of revision id → vertical centre (px) in the gutter's coordinate space.
   * Computed by the parent so the gutter shares ONE coordinate space with the
   * list — it already accounts for day-header heights, so dots line up with
   * their rows even when `groupBy="day"` inserts headers between groups.
   */
  rowCenterY: Map<string, number>;
  /** Total gutter height (px) — equals the rendered list height. */
  height: number;
  className?: string;
}

/**
 * Renders the branch-graph SVG gutter. Draws:
 *   - A vertical spine per lane (coloured via chart tokens)
 *   - A filled circle node at each revision's lane position
 *   - Merge-join cubic-bezier curves between a child revision and its parent
 *     revision when they are in different lanes (cross-lane edges)
 *
 * All Y positions come from `rowCenterY` (header-aware), NOT `index * ROW_H`,
 * so the graph stays aligned with day-grouped rows. No `absolute w-px`
 * connectors — all drawing is SVG (timeline-fork safe).
 */
function LaneGutter({ revisions, edges, rowCenterY, height, className }: LaneGutterProps) {
  const maxLane = revisions.reduce((m, r) => Math.max(m, r.lane), 0);
  const svgW = (maxLane + 1) * LANE_W;

  const idToRev = useMemo(() => {
    const m = new Map<string, Revision>();
    for (const r of revisions) m.set(r.id, r);
    return m;
  }, [revisions]);

  // Each lane's first + last revision (in list order) bound its spine.
  const laneSpan = useMemo(() => {
    const first = new Map<number, string>();
    const last = new Map<number, string>();
    for (const r of revisions) {
      if (!first.has(r.lane)) first.set(r.lane, r.id);
      last.set(r.lane, r.id);
    }
    return { first, last };
  }, [revisions]);

  // Pre-count incoming edges per revision → merge detection.
  const incomingCount = useMemo(() => {
    const m = new Map<string, number>();
    for (const e of edges) m.set(e.to, (m.get(e.to) ?? 0) + 1);
    return m;
  }, [edges]);

  if (height === 0 || revisions.length === 0) return null;

  return (
    <svg
      aria-hidden="true"
      width={svgW}
      height={height}
      className={cn("shrink-0 self-stretch", className)}
      style={{ minWidth: svgW }}
    >
      {/* Lane spines — one vertical line per lane from first to last revision */}
      {Array.from(laneSpan.last.entries()).map(([lane, lastId]) => {
        const firstId = laneSpan.first.get(lane);
        const y1 = firstId ? rowCenterY.get(firstId) : undefined;
        const y2 = rowCenterY.get(lastId);
        if (y1 === undefined || y2 === undefined) return null;
        const x = laneX(lane);
        return (
          <line
            key={`spine-${lane}`}
            x1={x}
            y1={y1}
            x2={x}
            y2={y2}
            stroke={laneColor(lane)}
            strokeWidth={2}
            strokeLinecap="round"
            opacity={0.5}
          />
        );
      })}

      {/* Edge connectors — cross-lane merge / fork joins */}
      {edges.map((edge, ei) => {
        const fromRev = idToRev.get(edge.from);
        const toRev = idToRev.get(edge.to);
        if (!fromRev || !toRev) return null;
        if (fromRev.lane === toRev.lane) return null; // covered by the spine
        const y1 = rowCenterY.get(fromRev.id);
        const y2 = rowCenterY.get(toRev.id);
        if (y1 === undefined || y2 === undefined) return null;
        const x1 = laneX(fromRev.lane);
        const x2 = laneX(toRev.lane);
        // Control points scale with the row span so multi-row merges curve smoothly.
        const dy = (y2 - y1) * 0.5;
        return (
          <path
            key={`edge-${ei}`}
            d={`M ${x1} ${y1} C ${x1} ${y1 + dy}, ${x2} ${y2 - dy}, ${x2} ${y2}`}
            stroke={laneColor(fromRev.lane)}
            strokeWidth={2}
            fill="none"
            strokeLinecap="round"
            opacity={0.7}
          />
        );
      })}

      {/* Node dots — one circle per revision */}
      {revisions.map((rev) => {
        const x = laneX(rev.lane);
        const y = rowCenterY.get(rev.id);
        if (y === undefined) return null;
        const isMerge = (incomingCount.get(rev.id) ?? 0) >= 2;
        return (
          <g key={`node-${rev.id}`}>
            {isMerge ? (
              <>
                <circle
                  cx={x}
                  cy={y}
                  r={NODE_R + 2}
                  fill="var(--background)"
                  stroke={laneColor(rev.lane)}
                  strokeWidth={2}
                />
                <circle cx={x} cy={y} r={NODE_R - 1} fill={laneColor(rev.lane)} />
              </>
            ) : (
              <circle cx={x} cy={y} r={NODE_R} fill={laneColor(rev.lane)} />
            )}
          </g>
        );
      })}
    </svg>
  );
}

// ─── Day group header ─────────────────────────────────────────────────────────

interface DayHeaderProps {
  label: string;
}

function DayHeader({ label }: DayHeaderProps) {
  // Fixed height (DAY_HEADER_H) so the SVG gutter's coordinate space stays in
  // lockstep with the rendered rows — see LaneGutter / rowCenterY.
  return (
    <div
      role="separator"
      aria-label={label}
      style={{ height: DAY_HEADER_H }}
      className="box-border flex items-center gap-3 px-3"
    >
      <span className="text-meta font-medium uppercase tracking-wide text-muted-foreground">
        {label}
      </span>
      <div className="h-px flex-1 bg-border" aria-hidden="true" />
    </div>
  );
}

// ─── Churn indicator ──────────────────────────────────────────────────────────

interface ChurnProps {
  additions?: number;
  deletions?: number;
}

function Churn({ additions, deletions }: ChurnProps) {
  const hasAdditions = additions !== undefined && additions > 0;
  const hasDeletions = deletions !== undefined && deletions > 0;
  if (!hasAdditions && !hasDeletions) return null;

  return (
    <span
      className="flex shrink-0 items-center gap-1 tabular-nums text-meta text-muted-foreground"
      aria-label={`${additions ?? 0} additions, ${deletions ?? 0} deletions`}
    >
      {hasAdditions && (
        <span className="flex items-center gap-0.5 text-success-text" aria-hidden="true">
          <Plus aria-hidden="true" className="size-2.5" />
          {additions}
        </span>
      )}
      {hasDeletions && (
        <span className="flex items-center gap-0.5 text-destructive" aria-hidden="true">
          <Minus aria-hidden="true" className="size-2.5" />
          {deletions}
        </span>
      )}
    </span>
  );
}

// ─── Ref chip ─────────────────────────────────────────────────────────────────

function RefChip({ label }: { label: string }) {
  return (
    <span className="inline-flex shrink-0 items-center rounded border border-border bg-muted px-1.5 py-0.5 text-meta text-muted-foreground">
      {label}
    </span>
  );
}

// ─── Revision row ────────────────────────────────────────────────────────────

interface RevisionRowProps {
  revision: Revision;
  isMerge: boolean;
  density: RevisionTimelineDensity;
}

function RevisionRow({ revision, isMerge, density }: RevisionRowProps) {
  const { selectedId, onSelect } = useRevisionTimelineCtx();
  const isSelected = selectedId === revision.id;
  const ROW_H = density === "compact" ? ROW_H_COMPACT : ROW_H_COMFORTABLE;

  const formattedTimestamp = useMemo(() => {
    const d =
      revision.timestamp instanceof Date ? revision.timestamp : new Date(revision.timestamp);
    return new Intl.DateTimeFormat(undefined, {
      hour: "2-digit",
      minute: "2-digit",
    }).format(d);
  }, [revision.timestamp]);

  const fullTimestamp = useMemo(() => {
    const d =
      revision.timestamp instanceof Date ? revision.timestamp : new Date(revision.timestamp);
    return new Intl.DateTimeFormat(undefined, {
      dateStyle: "full",
      timeStyle: "medium",
    }).format(d);
  }, [revision.timestamp]);

  return (
    <li
      role="listitem"
      data-revision-id={revision.id}
      data-selected={isSelected || undefined}
      style={{ height: ROW_H }}
      className="relative flex items-center"
    >
      <button
        type="button"
        aria-label={`Select revision: ${revision.message}`}
        aria-pressed={isSelected}
        onClick={() => onSelect(revision.id)}
        className={cn(
          "flex h-full w-full min-w-0 items-center gap-2 px-2 text-start",
          "transition-colors duration-fast ease-standard motion-reduce:transition-none",
          "rounded focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
          "hover:bg-accent hover:text-accent-foreground",
          isSelected && "border-s-2 border-s-primary bg-accent text-accent-foreground",
        )}
      >
        {/* Merge icon (non-color visual cue for merge commits) */}
        <span className="shrink-0 text-muted-foreground" aria-hidden="true">
          {isMerge ? (
            <GitMerge className="size-3.5" aria-hidden="true" />
          ) : (
            <GitCommitHorizontal className="size-3.5" aria-hidden="true" />
          )}
        </span>

        {/* Commit message — truncates with min-w-0 */}
        <span
          className="min-w-0 flex-1 truncate text-body text-foreground"
          title={revision.message}
        >
          {revision.message}
        </span>

        {/* Ref chips (branch / tag labels) */}
        {revision.refs && revision.refs.length > 0 && (
          <span className="hidden shrink-0 items-center gap-1 sm:flex">
            {revision.refs.map((ref) => (
              <RefChip key={ref} label={ref} />
            ))}
          </span>
        )}

        {/* Churn indicators */}
        <Churn additions={revision.additions} deletions={revision.deletions} />

        {/* Author */}
        {revision.author && (
          <span
            className="hidden shrink-0 text-caption text-muted-foreground md:block"
            title={revision.author}
          >
            {revision.author}
          </span>
        )}

        {/* Short SHA */}
        {revision.shortSha && (
          <span
            className="hidden shrink-0 font-mono text-meta text-muted-foreground sm:block"
            title={`Full SHA: ${revision.shortSha}`}
          >
            {revision.shortSha}
          </span>
        )}

        {/* Timestamp */}
        <time
          dateTime={
            revision.timestamp instanceof Date
              ? revision.timestamp.toISOString()
              : new Date(revision.timestamp).toISOString()
          }
          className="shrink-0 text-meta text-muted-foreground"
          title={fullTimestamp}
        >
          {formattedTimestamp}
        </time>
      </button>
    </li>
  );
}

// ─── Main component ───────────────────────────────────────────────────────────

export interface RevisionTimelineProps
  extends
    Omit<HTMLAttributes<HTMLDivElement>, "onSelect">,
    VariantProps<typeof revisionTimelineVariants> {
  /** Ordered revisions, newest → oldest. */
  revisions: Revision[];
  /**
   * Parent-link edges for drawing the branch graph.
   * Each edge connects a child revision (`from`) to its parent (`to`).
   */
  edges?: RevisionEdge[];
  /**
   * How to group revisions. `"day"` inserts day headers; `"none"` renders a
   * flat list. @default "day"
   */
  groupBy?: "day" | "none";
  /** Format the day-group header label. Defaults to `Intl.DateTimeFormat` long date. */
  formatDay?: (d: Date) => string;
  /**
   * Controlled selection: the id of the currently-selected revision.
   * Omit to use uncontrolled selection (`defaultSelectedId`).
   */
  selectedId?: string;
  /** Initial selected revision id for uncontrolled usage. */
  defaultSelectedId?: string;
  /** Called when the user selects a revision row. */
  onSelect?: (id: string) => void;
}

/**
 * RevisionTimeline — presentational git-history timeline.
 *
 * Renders revisions in a scrollable list with:
 *   - Day grouping (collapsible via `groupBy`)
 *   - SVG branch-graph lanes + merge joins in the left gutter
 *   - Churn indicators, ref chips, author, SHA, timestamp
 *   - Accessible selection (real `<button>` elements in an `<ol>`)
 *
 * Self-contained: no required Provider ancestor. Use `selectedId` +
 * `onSelect` for controlled selection, or `defaultSelectedId` for uncontrolled.
 */
export const RevisionTimeline = forwardRef<HTMLDivElement, RevisionTimelineProps>(
  function RevisionTimeline(
    {
      revisions,
      edges = [],
      groupBy = "day",
      formatDay,
      selectedId: controlledSelectedId,
      defaultSelectedId,
      onSelect,
      density,
      className,
      ...props
    },
    ref,
  ) {
    const resolvedDensity: RevisionTimelineDensity = density ?? "comfortable";

    // Controlled / uncontrolled selection
    const isControlled = controlledSelectedId !== undefined;
    const [internalSelectedId, setInternalSelectedId] = useState<string | undefined>(
      defaultSelectedId,
    );
    const resolvedSelectedId = isControlled ? controlledSelectedId : internalSelectedId;

    const handleSelect = useCallback(
      (id: string) => {
        onSelect?.(id);
        if (!isControlled) {
          setInternalSelectedId(id);
        }
      },
      [isControlled, onSelect],
    );

    // Default day formatter
    const defaultFormatDay = useCallback(
      (d: Date) =>
        new Intl.DateTimeFormat(undefined, {
          weekday: "short",
          month: "short",
          day: "numeric",
          year: "numeric",
        }).format(d),
      [],
    );
    const resolvedFormatDay = formatDay ?? defaultFormatDay;

    // Merge detection: revision is a merge if ≥2 incoming edges target it
    const mergeIds = useMemo(() => {
      const incoming = new Map<string, number>();
      for (const e of edges) {
        incoming.set(e.to, (incoming.get(e.to) ?? 0) + 1);
      }
      return new Set([...incoming.entries()].filter(([, n]) => n >= 2).map(([id]) => id));
    }, [edges]);

    // Group revisions by day
    const groups = useMemo<
      Array<{ dayKey: string; dayLabel: string; revisions: Revision[] }>
    >(() => {
      if (groupBy === "none") {
        return [{ dayKey: "all", dayLabel: "", revisions }];
      }
      const result: Array<{ dayKey: string; dayLabel: string; revisions: Revision[] }> = [];
      for (const rev of revisions) {
        const d = rev.timestamp instanceof Date ? rev.timestamp : new Date(rev.timestamp);
        // YYYY-MM-DD in local time for grouping key
        const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
        const last = result[result.length - 1];
        if (last && last.dayKey === key) {
          last.revisions.push(rev);
        } else {
          result.push({ dayKey: key, dayLabel: resolvedFormatDay(d), revisions: [rev] });
        }
      }
      return result;
    }, [revisions, groupBy, resolvedFormatDay]);

    // Shared gutter↔list coordinate space: a per-revision vertical centre that
    // already accounts for day-header height, so the SVG dots line up with
    // their rows even when `groupBy="day"` inserts headers between groups.
    const ROW_H = resolvedDensity === "compact" ? ROW_H_COMPACT : ROW_H_COMFORTABLE;
    const { rowCenterY, gutterHeight } = useMemo(() => {
      const map = new Map<string, number>();
      let y = 0;
      for (const group of groups) {
        if (groupBy === "day") y += DAY_HEADER_H;
        for (const rev of group.revisions) {
          map.set(rev.id, y + ROW_H / 2);
          y += ROW_H;
        }
      }
      return { rowCenterY: map, gutterHeight: y };
    }, [groups, groupBy, ROW_H]);

    const ctx: RevisionTimelineCtx = useMemo(
      () => ({
        selectedId: resolvedSelectedId,
        onSelect: handleSelect,
      }),
      [resolvedSelectedId, handleSelect],
    );

    return (
      <RevisionTimelineContext.Provider value={ctx}>
        <div
          ref={ref}
          className={cn(revisionTimelineVariants({ density: resolvedDensity }), className)}
          {...props}
        >
          {/* Lane gutter + list side-by-side */}
          <div className="flex min-w-0">
            {/* SVG branch-graph gutter */}
            <LaneGutter
              revisions={revisions}
              edges={edges}
              rowCenterY={rowCenterY}
              height={gutterHeight}
              className="mr-1"
            />

            {/* Revision list */}
            <div className="min-w-0 flex-1">
              {groups.map((group) => (
                <div key={group.dayKey}>
                  {groupBy === "day" && <DayHeader label={group.dayLabel} />}
                  <ol role="list" aria-label={groupBy === "day" ? group.dayLabel : "Revisions"}>
                    {group.revisions.map((rev) => (
                      <RevisionRow
                        key={rev.id}
                        revision={rev}
                        isMerge={mergeIds.has(rev.id)}
                        density={resolvedDensity}
                      />
                    ))}
                  </ol>
                </div>
              ))}
            </div>
          </div>
        </div>
      </RevisionTimelineContext.Provider>
    );
  },
);
