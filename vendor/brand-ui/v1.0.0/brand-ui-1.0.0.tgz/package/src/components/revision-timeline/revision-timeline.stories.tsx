import type { Meta, StoryObj } from "@storybook/react-vite";
import { expect, fn, userEvent, within } from "storybook/test";
import { useState } from "react";
import { RevisionTimeline, type Revision, type RevisionEdge } from "./revision-timeline";

const meta = {
  title: "Data/RevisionTimeline",
  component: RevisionTimeline,
  tags: ["autodocs"],
  parameters: {
    layout: "padded",
    docs: {
      description: {
        component:
          "A presentational git-history timeline. Renders revisions (newest-first) with " +
          "day grouping, an SVG branch-graph lane gutter, churn indicators (+/−), " +
          "ref chips, and an accessible selection rail. The app computes lane indices " +
          "and edges; the component only renders what it receives.",
      },
    },
  },
  argTypes: {
    density: {
      control: "select",
      options: ["comfortable", "compact"],
    },
    groupBy: {
      control: "select",
      options: ["day", "none"],
    },
  },
} satisfies Meta<typeof RevisionTimeline>;

export default meta;
type Story = StoryObj<typeof meta>;

// ─── Shared fixture data ────────────────────────────────────────────────────

const DAY1 = new Date("2024-06-14T09:15:00");
const DAY1_B = new Date("2024-06-14T11:42:00");
const DAY2 = new Date("2024-06-13T14:30:00");
const DAY2_B = new Date("2024-06-13T16:05:00");
const DAY3 = new Date("2024-06-12T10:00:00");

const LINEAR_REVISIONS: Revision[] = [
  {
    id: "a1",
    message: "feat: add RevisionTimeline component with SVG lane gutter",
    author: "M. Reimitz",
    shortSha: "a1b2c3d",
    timestamp: DAY1,
    additions: 312,
    deletions: 14,
    lane: 0,
    refs: ["HEAD", "main"],
  },
  {
    id: "a2",
    message: "fix: correct token usage in churn indicators",
    author: "M. Reimitz",
    shortSha: "e4f5a6b",
    timestamp: DAY1_B,
    additions: 8,
    deletions: 3,
    lane: 0,
  },
  {
    id: "a3",
    message: "chore: update text-scale baseline after typography cleanup",
    author: "A. Chen",
    shortSha: "c7d8e9f",
    timestamp: DAY2,
    additions: 2,
    deletions: 0,
    lane: 0,
  },
  {
    id: "a4",
    message: "refactor: extract LaneGutter into its own function",
    author: "A. Chen",
    shortSha: "f1a2b3c",
    timestamp: DAY2_B,
    additions: 45,
    deletions: 38,
    lane: 0,
  },
  {
    id: "a5",
    message: "docs: add ADR-0014 for revision timeline design decisions",
    author: "M. Reimitz",
    shortSha: "d4e5f6a",
    timestamp: DAY3,
    additions: 90,
    deletions: 0,
    lane: 0,
  },
];

// ─── Stories ────────────────────────────────────────────────────────────────

/** Linear history — single lane, grouped by day (the common case). */
export const LinearHistory: Story = {
  args: {
    revisions: LINEAR_REVISIONS,
    groupBy: "day",
  },
  play: async ({ canvasElement }) => {
    const canvas = within(canvasElement);

    // Day group headers render
    const separators = canvas.getAllByRole("separator");
    expect(separators.length).toBeGreaterThanOrEqual(2);

    // Each revision is a listitem with a button
    const items = canvas.getAllByRole("listitem");
    expect(items).toHaveLength(LINEAR_REVISIONS.length);

    // First revision message is visible
    await expect(
      canvas.getByText("feat: add RevisionTimeline component with SVG lane gutter"),
    ).toBeVisible();

    // Churn is rendered with tabular-nums
    const churnEl = canvasElement.querySelector('[aria-label*="additions"]');
    expect(churnEl).not.toBeNull();
  },
};

/** Branch + merge history — two lanes with a cross-lane merge join in the SVG gutter. */
const BRANCH_REVISIONS: Revision[] = [
  {
    id: "m1",
    message: "Merge branch 'feat/dark-mode' into main",
    author: "M. Reimitz",
    shortSha: "merge01",
    timestamp: new Date("2024-06-14T15:00:00"),
    additions: 0,
    deletions: 0,
    lane: 0,
    refs: ["HEAD", "main"],
  },
  {
    id: "f1",
    message: "feat: dark-mode support for RevisionTimeline",
    author: "A. Chen",
    shortSha: "dark001",
    timestamp: new Date("2024-06-14T13:00:00"),
    additions: 55,
    deletions: 12,
    lane: 1,
    refs: ["feat/dark-mode"],
  },
  {
    id: "b1",
    message: "chore: bump tokens package version",
    author: "M. Reimitz",
    shortSha: "bump001",
    timestamp: new Date("2024-06-14T11:00:00"),
    additions: 2,
    deletions: 2,
    lane: 0,
  },
  {
    id: "f0",
    message: "feat: scaffold dark-mode branch",
    author: "A. Chen",
    shortSha: "dark000",
    timestamp: new Date("2024-06-13T17:00:00"),
    additions: 10,
    deletions: 0,
    lane: 1,
  },
  {
    id: "b0",
    message: "chore: initial commit",
    author: "M. Reimitz",
    shortSha: "init000",
    timestamp: new Date("2024-06-13T09:00:00"),
    additions: 120,
    deletions: 0,
    lane: 0,
    refs: ["origin/main"],
  },
];

const BRANCH_EDGES: RevisionEdge[] = [
  // Merge commit m1 has two parents: f1 (feat branch) and b1 (main)
  { from: "m1", to: "f1" },
  { from: "m1", to: "b1" },
  // feat branch lineage
  { from: "f1", to: "f0" },
  { from: "f0", to: "b0" },
  // main lineage
  { from: "b1", to: "b0" },
];

/** Branch and merge — two lanes with a merge commit, showing SVG cross-lane bezier curves. */
export const BranchAndMerge: Story = {
  args: {
    revisions: BRANCH_REVISIONS,
    edges: BRANCH_EDGES,
    groupBy: "day",
  },
  play: async ({ canvasElement }) => {
    const canvas = within(canvasElement);

    // Merge commit renders with GitMerge icon (identified via aria-label on button)
    const mergeBtn = canvas.getByRole("button", {
      name: /Merge branch 'feat\/dark-mode' into main/,
    });
    expect(mergeBtn).toBeInTheDocument();

    // All 5 revisions render
    expect(canvas.getAllByRole("listitem")).toHaveLength(BRANCH_REVISIONS.length);

    // The SVG gutter is present (aria-hidden)
    const svg = canvasElement.querySelector("svg[aria-hidden='true']");
    expect(svg).not.toBeNull();

    // Day group headers present for two different days
    expect(canvas.getAllByRole("separator").length).toBeGreaterThanOrEqual(2);
  },
};

/** Selection — demonstrates controlled and uncontrolled selection with onSelect callback. */
export const Selection: Story = {
  args: {
    revisions: LINEAR_REVISIONS.slice(0, 4),
    groupBy: "none",
    onSelect: fn(),
  },
  play: async ({ canvasElement, args }) => {
    const canvas = within(canvasElement);
    const user = userEvent.setup();

    const buttons = canvas.getAllByRole("button");
    expect(buttons.length).toBeGreaterThan(0);

    // Click the first revision button
    await user.click(buttons[0]!);

    // onSelect should have been called with the first revision id
    expect(args.onSelect).toHaveBeenCalledWith(LINEAR_REVISIONS[0]!.id);

    // The button should now be aria-pressed
    await expect(buttons[0]).toHaveAttribute("aria-pressed", "true");

    // Click a second revision
    await user.click(buttons[1]!);
    expect(args.onSelect).toHaveBeenCalledWith(LINEAR_REVISIONS[1]!.id);

    // First button is no longer selected
    await expect(buttons[0]).toHaveAttribute("aria-pressed", "false");
  },
};

/** Compact density — tighter row height for dense information displays. */
export const Compact: Story = {
  args: {
    revisions: LINEAR_REVISIONS,
    density: "compact",
    groupBy: "day",
  },
  play: async ({ canvasElement }) => {
    const canvas = within(canvasElement);
    expect(canvas.getAllByRole("listitem")).toHaveLength(LINEAR_REVISIONS.length);
  },
};

/** Controlled selection — parent manages the selected id externally. */
export const ControlledSelection: Story = {
  args: {
    revisions: LINEAR_REVISIONS.slice(0, 3),
    groupBy: "none",
  },
  render: (args) => {
    // eslint-disable-next-line react-hooks/rules-of-hooks
    const [selected, setSelected] = useState<string>(LINEAR_REVISIONS[1]!.id);
    return (
      <div className="space-y-3">
        <p className="text-caption text-muted-foreground">
          Selected: <code className="font-mono">{selected}</code>
        </p>
        <RevisionTimeline {...args} selectedId={selected} onSelect={(id) => setSelected(id)} />
      </div>
    );
  },
  play: async ({ canvasElement }) => {
    const canvas = within(canvasElement);
    const buttons = canvas.getAllByRole("button");

    // Second button (index 1) is pre-selected
    await expect(buttons[1]).toHaveAttribute("aria-pressed", "true");
    await expect(buttons[0]).toHaveAttribute("aria-pressed", "false");
  },
};
