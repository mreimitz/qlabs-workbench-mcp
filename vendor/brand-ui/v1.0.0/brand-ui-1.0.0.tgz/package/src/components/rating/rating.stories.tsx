import type { Meta, StoryObj } from "@storybook/react";
import { useState } from "react";
import { Rating } from "./rating";

const meta = {
  title: "Forms/Rating",
  component: Rating,
  tags: ["autodocs"],
  argTypes: {
    size: { control: "inline-radio", options: ["sm", "md", "lg"] },
  },
} satisfies Meta<typeof Rating>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {
  args: { defaultValue: 3 },
};

export const Sizes: Story = {
  render: () => (
    <div className="flex flex-col gap-3">
      <Rating defaultValue={3} size="sm" aria-label="Small rating" />
      <Rating defaultValue={3} size="md" aria-label="Medium rating" />
      <Rating defaultValue={3} size="lg" aria-label="Large rating" />
    </div>
  ),
};

export const HalfSteps: Story = {
  args: { defaultValue: 2.5, allowHalf: true },
};

export const ReadOnly: Story = {
  args: { value: 4, readOnly: true },
};

export const Disabled: Story = {
  args: { defaultValue: 2, disabled: true },
};

export const Controlled: Story = {
  render: () => {
    // eslint-disable-next-line react-hooks/rules-of-hooks
    const [value, setValue] = useState(3);
    return (
      <div className="flex flex-col gap-2">
        <Rating value={value} onValueChange={setValue} aria-label="Controlled rating" />
        <p className="text-muted-foreground text-sm tabular-nums">Value: {value}</p>
      </div>
    );
  },
};
