import type { Meta, StoryObj } from "@storybook/react-vite";
import { MetricCard } from "./metric-card";

const meta = {
  title: "Foundation/MetricCard",
  component: MetricCard,
  tags: ["autodocs"],
  parameters: {
    layout: "padded",
  },
} satisfies Meta<typeof MetricCard>;
export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {
  args: {
    label: "Active users",
    value: "24,512",
    delta: "12.4%",
    deltaDirection: "up",
  },
};

export const WithDescription: Story = {
  args: {
    label: "Monthly Revenue",
    value: "$84.2k",
    description: "vs $80.9k last month",
    delta: "4.1%",
    deltaDirection: "up",
  },
};

export const DeltaDown: Story = {
  args: {
    label: "Churn Rate",
    value: "1.8%",
    description: "0.3 pp worse than target",
    delta: "0.3%",
    deltaDirection: "down",
    positiveIsGood: false,
  },
};

export const DeltaUnfavorable: Story = {
  args: {
    label: "Open tickets",
    value: "37",
    description: "15 unassigned",
    delta: "+9",
    deltaDirection: "up",
    positiveIsGood: false,
  },
};

export const Neutral: Story = {
  args: {
    label: "Sessions",
    value: "100",
    delta: "0%",
    deltaDirection: "neutral",
  },
};

export const NoMetrics: Story = {
  args: {
    label: "Open gaps",
    value: "2",
    description: "in progress",
  },
};

// emphasis="headline" — the answer-leading KPI rung (#191, research 11 §B.5):
// size/weight/space only, the polarity color system is unchanged.
export const Headline: Story = {
  args: {
    emphasis: "headline",
    label: "Net revenue retention",
    value: "118%",
    delta: "+4.2pp",
    deltaDirection: "up",
  },
};

export const WithEvidence: Story = {
  args: {
    label: "Enterprise churn",
    value: "1.8%",
    delta: "0.4pp",
    deltaDirection: "down",
    positiveIsGood: false,
    evidence: <span>Grounded in 3 sources</span>,
  },
};
