import type { Meta, StoryObj } from "@storybook/react-vite";
import { useState } from "react";
import { Folder, FileText } from "lucide-react";
import { TreeSelect } from "./tree-select";
import type { TreeNode } from "../tree";

const tree: TreeNode[] = [
  {
    id: "engineering",
    label: "Engineering",
    icon: <Folder className="size-4 text-muted-foreground" />,
    children: [
      {
        id: "frontend",
        label: "Frontend",
        icon: <FileText className="size-4 text-muted-foreground" />,
      },
      {
        id: "backend",
        label: "Backend",
        icon: <FileText className="size-4 text-muted-foreground" />,
      },
      {
        id: "platform",
        label: "Platform",
        icon: <FileText className="size-4 text-muted-foreground" />,
      },
    ],
  },
  {
    id: "design",
    label: "Design",
    icon: <Folder className="size-4 text-muted-foreground" />,
    children: [
      {
        id: "product-design",
        label: "Product Design",
        icon: <FileText className="size-4 text-muted-foreground" />,
      },
      {
        id: "research",
        label: "Research",
        icon: <FileText className="size-4 text-muted-foreground" />,
      },
    ],
  },
];

const meta = {
  title: "Forms/TreeSelect",
  component: TreeSelect,
  tags: ["autodocs"],
} satisfies Meta<typeof TreeSelect>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {
  args: { nodes: tree, placeholder: "Select a team" },
};

export const Preselected: Story = {
  args: { nodes: tree, defaultValue: "frontend" },
};

function MultipleExample() {
  const [value, setValue] = useState<string[]>(["frontend", "research"]);
  return (
    <TreeSelect
      nodes={tree}
      multiple
      value={value}
      onValueChange={(v) => setValue(v as string[])}
      placeholder="Select teams"
    />
  );
}

export const Multiple: Story = {
  render: () => <MultipleExample />,
};
