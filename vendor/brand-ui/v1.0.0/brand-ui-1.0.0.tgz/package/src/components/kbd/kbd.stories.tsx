import type { Meta, StoryObj } from "@storybook/react-vite";
import { Kbd } from "./kbd";
const meta = { title: "Display/Kbd", component: Kbd, tags: ["autodocs"] } satisfies Meta<
  typeof Kbd
>;
export default meta;
type Story = StoryObj<typeof meta>;
export const Default: Story = {
  render: () => (
    <span className="text-sm">
      Press <Kbd>⌘</Kbd> <Kbd>K</Kbd>
    </span>
  ),
};
