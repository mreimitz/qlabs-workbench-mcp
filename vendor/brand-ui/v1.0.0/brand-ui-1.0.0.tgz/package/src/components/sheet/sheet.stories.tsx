import type { Meta, StoryObj } from "@storybook/react-vite";
import { Button } from "../button";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "./sheet";
const meta = { title: "Overlays/Sheet", component: Sheet, tags: ["autodocs"] } satisfies Meta<
  typeof Sheet
>;
export default meta;
type Story = StoryObj<typeof meta>;
export const Default: Story = {
  render: () => (
    <Sheet>
      <SheetTrigger asChild>
        <Button variant="outline">Open sheet</Button>
      </SheetTrigger>
      <SheetContent>
        <SheetHeader>
          <SheetTitle>Settings</SheetTitle>
          <SheetDescription>Manage your workspace.</SheetDescription>
        </SheetHeader>
      </SheetContent>
    </Sheet>
  ),
};
