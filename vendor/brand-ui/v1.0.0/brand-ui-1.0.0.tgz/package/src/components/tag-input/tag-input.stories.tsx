import type { Meta, StoryObj } from "@storybook/react-vite";
import { useState } from "react";
import { TagInput } from "./tag-input";

const meta = {
  title: "Forms/TagInput",
  component: TagInput,
  tags: ["autodocs"],
  args: {
    placeholder: "Add tag…",
  },
} satisfies Meta<typeof TagInput>;
export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {
  args: { defaultValue: ["react", "typescript"] },
};

export const Controlled: Story = {
  render: () => {
    // eslint-disable-next-line react-hooks/rules-of-hooks
    const [tags, setTags] = useState(["design", "system"]);
    return (
      <div className="flex flex-col gap-2 max-w-sm">
        <TagInput value={tags} onValueChange={setTags} placeholder="Add tag…" />
        <p className="text-sm text-muted-foreground">Tags: {tags.join(", ") || "none"}</p>
      </div>
    );
  },
};

export const WithMax: Story = {
  args: { defaultValue: ["one", "two"], max: 3, placeholder: "Max 3 tags…" },
};

export const WithValidation: Story = {
  args: {
    defaultValue: [],
    placeholder: "Only lowercase letters…",
    validate: (tag) => {
      if (!/^[a-z]+$/.test(tag)) return "Only lowercase letters allowed.";
      return true;
    },
  },
};

export const AllowDuplicates: Story = {
  args: { defaultValue: ["foo"], allowDuplicates: true, placeholder: "Duplicates OK…" },
};

export const Disabled: Story = {
  args: { defaultValue: ["locked"], disabled: true },
};

export const Empty: Story = {
  args: { placeholder: "Type and press Enter or comma…" },
};
