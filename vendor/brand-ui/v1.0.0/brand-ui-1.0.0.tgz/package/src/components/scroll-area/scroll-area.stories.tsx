import type { Meta, StoryObj } from "@storybook/react-vite";
import { ScrollArea } from "./scroll-area";
const meta = {
  title: "Display/ScrollArea",
  component: ScrollArea,
  tags: ["autodocs"],
} satisfies Meta<typeof ScrollArea>;
export default meta;
type Story = StoryObj<typeof meta>;
export const Default: Story = {
  render: () => (
    <ScrollArea className="h-40 w-56 rounded-md border p-3">
      <div className="space-y-2 text-sm">
        {Array.from({ length: 20 }).map((_, i) => (
          <p key={i}>Row {i + 1}</p>
        ))}
      </div>
    </ScrollArea>
  ),
};
