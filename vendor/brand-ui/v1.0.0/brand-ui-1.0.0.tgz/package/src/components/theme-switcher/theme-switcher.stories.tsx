import type { Meta, StoryObj } from "@storybook/react-vite";
import { THEMES, ThemeProvider } from "@brand/tokens";

import { ThemeSwitcher } from "./theme-switcher";

const meta = {
  title: "Foundation/ThemeSwitcher",
  component: ThemeSwitcher,
  tags: ["autodocs"],
  decorators: [
    (Story) => (
      <ThemeProvider>
        <div className="flex min-h-32 items-center justify-center">
          <Story />
        </div>
      </ThemeProvider>
    ),
  ],
  argTypes: {
    mode: { control: "inline-radio", options: ["auto", "toggle", "dropdown"] },
    effect: { control: "select", options: ["polygon", "circle", "circle-blur", "triangle"] },
    size: { control: "inline-radio", options: ["sm", "default", "lg"] },
    showSystem: { control: "boolean" },
  },
} satisfies Meta<typeof ThemeSwitcher>;
export default meta;

type Story = StoryObj<typeof meta>;

/** Default: the Qlik light/dark pair → a cycling light / dark / system toggle. */
export const Toggle: Story = {};

/** More than two themes → auto-upgrades to a dropdown over all of them. */
export const Dropdown: Story = { args: { themes: [...THEMES] } };

/** Toggle without the System option (light / dark only). */
export const ToggleNoSystem: Story = { args: { showSystem: false } };

/** A neutral light/dark pair, for apps that don't use the Qlik themes. */
export const NeutralPair: Story = { args: { themes: ["light", "dark"] } };
