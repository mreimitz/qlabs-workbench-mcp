import type { Meta, StoryObj } from "@storybook/react-vite";
import { Button } from "../button";
import { ErrorState } from "./error-state";

const meta = {
  title: "States/ErrorState",
  component: ErrorState,
  tags: ["autodocs"],
} satisfies Meta<typeof ErrorState>;
export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {
  args: {
    actions: (
      <Button size="sm" variant="outline">
        Retry
      </Button>
    ),
  },
};
