import type { Meta, StoryObj } from "@storybook/react-vite";
import { Spinner } from "./spinner";
const meta = { title: "Display/Spinner", component: Spinner, tags: ["autodocs"] } satisfies Meta<
  typeof Spinner
>;
export default meta;
type Story = StoryObj<typeof meta>;
export const Default: Story = { render: () => <Spinner className="size-6" /> };
