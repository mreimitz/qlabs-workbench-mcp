import type { Meta, StoryObj } from "@storybook/react-vite";
import { Bold } from "lucide-react";
import { Toggle } from "./toggle";
const meta = { title: "Forms/Toggle", component: Toggle, tags: ["autodocs"] } satisfies Meta<
  typeof Toggle
>;
export default meta;
type Story = StoryObj<typeof meta>;
export const Default: Story = { args: { "aria-label": "Bold", children: <Bold /> } };
export const Pressed: Story = {
  args: { "aria-label": "Bold", children: <Bold />, pressed: true },
};
export const Outline: Story = { args: { variant: "outline", children: "Bold" } };
export const OutlinePressed: Story = {
  args: { variant: "outline", children: "Bold", pressed: true },
};
export const Disabled: Story = {
  args: { "aria-label": "Bold", children: <Bold />, disabled: true },
};
