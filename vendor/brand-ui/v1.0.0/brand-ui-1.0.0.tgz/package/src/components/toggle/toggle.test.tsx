import { describe, expect, it } from "vitest";
import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { Toggle } from "./toggle";
describe("Toggle", () => {
  it("toggles pressed state", async () => {
    render(<Toggle aria-label="t">B</Toggle>);
    const t = screen.getByRole("button", { name: "t" });
    await userEvent.click(t);
    expect(t).toHaveAttribute("data-state", "on");
  });
});
