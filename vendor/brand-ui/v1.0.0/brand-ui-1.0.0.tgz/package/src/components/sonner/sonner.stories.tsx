import type { Meta, StoryObj } from "@storybook/react-vite";
import { Button } from "../button";
import { Toaster, toast } from "./sonner";
const meta = {
  title: "Feedback/Toast (Sonner)",
  component: Toaster,
  tags: ["autodocs"],
} satisfies Meta<typeof Toaster>;
export default meta;
type Story = StoryObj<typeof meta>;
export const Default: Story = {
  render: () => (
    <div>
      <Button onClick={() => toast("Deployment started", { description: "billing@v1.4.2" })}>
        Show toast
      </Button>
      <Toaster />
    </div>
  ),
};
