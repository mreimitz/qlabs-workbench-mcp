import type { Meta, StoryObj } from "@storybook/react-vite";
import { Button } from "../button";
import { HoverCard, HoverCardContent, HoverCardTrigger } from "./hover-card";
const meta = {
  title: "Overlays/HoverCard",
  component: HoverCard,
  tags: ["autodocs"],
} satisfies Meta<typeof HoverCard>;
export default meta;
type Story = StoryObj<typeof meta>;
export const Default: Story = {
  render: () => (
    <HoverCard>
      <HoverCardTrigger asChild>
        <Button variant="link">@brand</Button>
      </HoverCardTrigger>
      <HoverCardContent>The brand-ui design system.</HoverCardContent>
    </HoverCard>
  ),
};
