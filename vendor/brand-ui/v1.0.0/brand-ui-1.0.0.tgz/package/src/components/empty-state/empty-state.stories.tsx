import type { Meta, StoryObj } from "@storybook/react-vite";
import { Button } from "../button";
import { EmptyState } from "./empty-state";

const meta = {
  title: "States/EmptyState",
  component: EmptyState,
  tags: ["autodocs"],
} satisfies Meta<typeof EmptyState>;
export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {
  args: {
    title: "No projects yet",
    description: "Create your first project to get started.",
    actions: <Button size="sm">New project</Button>,
  },
};
