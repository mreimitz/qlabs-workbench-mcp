import type { Meta, StoryObj } from "@storybook/react-vite";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "./table";
const meta = { title: "Data/Table", component: Table, tags: ["autodocs"] } satisfies Meta<
  typeof Table
>;
export default meta;
type Story = StoryObj<typeof meta>;
export const Default: Story = {
  render: () => (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead>Service</TableHead>
          <TableHead>Status</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        <TableRow>
          <TableCell>api-gateway</TableCell>
          <TableCell>healthy</TableCell>
        </TableRow>
        <TableRow>
          <TableCell>billing</TableCell>
          <TableCell>degraded</TableCell>
        </TableRow>
      </TableBody>
    </Table>
  ),
};
