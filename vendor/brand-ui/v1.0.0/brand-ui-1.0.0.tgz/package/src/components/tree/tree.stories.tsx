import type { Meta, StoryObj } from "@storybook/react-vite";
import { useState } from "react";
import { Folder, File, FileText, Database, Server } from "lucide-react";
import { Tree, type TreeNode } from "./tree";

// ---------------------------------------------------------------------------
// Shared sample data
// ---------------------------------------------------------------------------

const fileTree: TreeNode[] = [
  {
    id: "src",
    label: "src",
    icon: <Folder className="size-4 text-muted-foreground" />,
    children: [
      {
        id: "components",
        label: "components",
        icon: <Folder className="size-4 text-muted-foreground" />,
        children: [
          {
            id: "button",
            label: "button.tsx",
            icon: <FileText className="size-4 text-muted-foreground" />,
          },
          {
            id: "tree-tsx",
            label: "tree.tsx",
            icon: <FileText className="size-4 text-muted-foreground" />,
          },
        ],
      },
      {
        id: "lib",
        label: "lib",
        icon: <Folder className="size-4 text-muted-foreground" />,
        children: [
          {
            id: "cn",
            label: "cn.ts",
            icon: <File className="size-4 text-muted-foreground" />,
          },
        ],
      },
      {
        id: "index",
        label: "index.ts",
        icon: <File className="size-4 text-muted-foreground" />,
      },
    ],
  },
  {
    id: "public",
    label: "public",
    icon: <Folder className="size-4 text-muted-foreground" />,
    children: [
      {
        id: "favicon",
        label: "favicon.ico",
        icon: <File className="size-4 text-muted-foreground" />,
      },
    ],
  },
  {
    id: "package-json",
    label: "package.json",
    icon: <File className="size-4 text-muted-foreground" />,
  },
];

const orgTree: TreeNode[] = [
  {
    id: "engineering",
    label: "Engineering",
    icon: <Server className="size-4 text-muted-foreground" />,
    children: [
      {
        id: "frontend",
        label: "Frontend",
        children: [
          { id: "alice", label: "Alice" },
          { id: "bob", label: "Bob" },
        ],
      },
      {
        id: "backend",
        label: "Backend",
        children: [
          { id: "charlie", label: "Charlie" },
          { id: "dana", label: "Dana", disabled: true },
        ],
      },
    ],
  },
  {
    id: "data",
    label: "Data",
    icon: <Database className="size-4 text-muted-foreground" />,
    children: [
      { id: "eve", label: "Eve" },
      { id: "frank", label: "Frank" },
    ],
  },
];

// ---------------------------------------------------------------------------
// 5 000-node flat tree for the virtualization story
// ---------------------------------------------------------------------------

function buildLargeTree(count: number): TreeNode[] {
  const nodes: TreeNode[] = [];
  for (let i = 0; i < count; i++) {
    nodes.push({ id: `node-${i}`, label: `Node ${i + 1}` });
  }
  return nodes;
}

const LARGE_NODES = buildLargeTree(5000);

// ---------------------------------------------------------------------------
// Lazy-loading demo data
// ---------------------------------------------------------------------------

function makeLazyRoot(): TreeNode[] {
  return [
    {
      id: "root-a",
      label: "Category A",
      hasChildren: true,
      icon: <Folder className="size-4 text-muted-foreground" />,
    },
    {
      id: "root-b",
      label: "Category B",
      hasChildren: true,
      icon: <Folder className="size-4 text-muted-foreground" />,
    },
    {
      id: "root-c",
      label: "Category C (fails to load)",
      hasChildren: true,
      icon: <Folder className="size-4 text-muted-foreground" />,
    },
    {
      id: "root-d",
      label: "Static leaf",
      icon: <File className="size-4 text-muted-foreground" />,
    },
  ];
}

async function fakeFetch(nodeId: string): Promise<TreeNode[]> {
  await new Promise((resolve) => setTimeout(resolve, 800));
  if (nodeId === "root-c") throw new Error("Network error");
  return [
    {
      id: `${nodeId}-child-1`,
      label: `${nodeId} / child 1`,
      hasChildren: true,
      icon: <Folder className="size-4 text-muted-foreground" />,
    },
    {
      id: `${nodeId}-child-2`,
      label: `${nodeId} / child 2`,
      icon: <FileText className="size-4 text-muted-foreground" />,
    },
    {
      id: `${nodeId}-child-3`,
      label: `${nodeId} / child 3`,
      icon: <FileText className="size-4 text-muted-foreground" />,
    },
  ];
}

// ---------------------------------------------------------------------------
// Meta
// ---------------------------------------------------------------------------

const meta = {
  title: "Navigation/Tree",
  component: Tree,
  tags: ["autodocs"],
  args: {
    nodes: fileTree,
    defaultExpandedIds: ["src", "components"],
  },
  parameters: {
    layout: "padded",
  },
} satisfies Meta<typeof Tree>;

export default meta;
type Story = StoryObj<typeof meta>;

// ---------------------------------------------------------------------------
// Existing stories (unchanged)
// ---------------------------------------------------------------------------

/** Default single-selection file tree with icons. */
export const Default: Story = {};

/** Multiple selection with checkboxes. */
export const Multiple: Story = {
  args: {
    nodes: orgTree,
    defaultExpandedIds: ["engineering", "frontend", "backend", "data"],
    selectionMode: "multiple",
    checkboxes: true,
  },
};

/** Fully expanded at mount via defaultExpandedIds. */
export const Expanded: Story = {
  args: {
    defaultExpandedIds: ["src", "components", "lib", "public"],
  },
};

/** Collapsed — no nodes expanded at start. */
export const Collapsed: Story = {
  args: {
    defaultExpandedIds: [],
  },
};

/** Nodes with disabled items. */
export const DisabledNodes: Story = {
  args: {
    nodes: orgTree,
    defaultExpandedIds: ["engineering", "frontend", "backend", "data"],
    selectionMode: "single",
  },
};

/** Deep nesting — 4 levels. */
export const DeepNesting: Story = {
  args: {
    nodes: [
      {
        id: "l1",
        label: "Level 1",
        children: [
          {
            id: "l2",
            label: "Level 2",
            children: [
              {
                id: "l3",
                label: "Level 3",
                children: [
                  { id: "l4a", label: "Level 4 — A" },
                  { id: "l4b", label: "Level 4 — B" },
                ],
              },
            ],
          },
        ],
      },
    ],
    defaultExpandedIds: ["l1", "l2", "l3"],
  },
};

/** Controlled expand + select with external state display. */
export const Controlled: Story = {
  render: () => {
    // eslint-disable-next-line react-hooks/rules-of-hooks
    const [expanded, setExpanded] = useState<string[]>(["src"]);
    // eslint-disable-next-line react-hooks/rules-of-hooks
    const [selected, setSelected] = useState<string[]>([]);
    return (
      <div className="flex gap-8">
        <Tree
          nodes={fileTree}
          expandedIds={expanded}
          onExpandedChange={setExpanded}
          selectedIds={selected}
          onSelectionChange={setSelected}
          className="w-64"
        />
        <div className="text-sm text-muted-foreground space-y-1">
          <p>
            <span className="font-medium">Expanded:</span> {expanded.join(", ") || "none"}
          </p>
          <p>
            <span className="font-medium">Selected:</span> {selected.join(", ") || "none"}
          </p>
        </div>
      </div>
    );
  },
};

/** No selection mode — purely navigational. */
export const NoSelection: Story = {
  args: {
    selectionMode: "none",
    defaultExpandedIds: ["src", "components"],
  },
};

// ---------------------------------------------------------------------------
// New story: 5 000-node virtualized tree
// ---------------------------------------------------------------------------

/**
 * 5 000 flat nodes rendered with `virtualize`. Only the visible window (~15–25
 * rows) is mounted in the DOM at any time; keyboard navigation and End/Home
 * work across all 5 000 items.
 */
export const Virtualized: Story = {
  args: {
    nodes: LARGE_NODES,
    virtualize: true,
    estimateRowHeight: 32,
    overscan: 8,
    maxHeight: "400px",
    selectionMode: "single",
    defaultExpandedIds: [],
  },
  parameters: {
    docs: {
      description: {
        story:
          "5 000 flat nodes with `virtualize={true}`. Only the visible window is in the DOM. Use keyboard ArrowDown/Up/Home/End to navigate; the virtualizer scrolls automatically.",
      },
    },
  },
};

// ---------------------------------------------------------------------------
// New story: lazy-loading children on demand
// ---------------------------------------------------------------------------

/**
 * Nodes marked `hasChildren: true` with no loaded `children` show the expand
 * chevron. On first expand, `loadChildren` is called; a skeleton loading row
 * appears under `aria-busy` while the request is in flight. Resolved children
 * are cached — re-expanding does not re-fetch. "Category C" simulates a
 * network error and shows the inline retry affordance.
 */
export const LazyLoading: Story = {
  args: {
    nodes: makeLazyRoot(),
    loadChildren: (node) => fakeFetch(node.id),
    selectionMode: "single",
    defaultExpandedIds: [],
  },
  parameters: {
    docs: {
      description: {
        story:
          "Children are fetched on first expand via `loadChildren`. The spinner appears in the expand chevron while loading. A failed load shows a retry button.",
      },
    },
  },
};
