/**
 * Tree component unit tests.
 *
 * Environment notes (jsdom):
 * - jsdom has zero layout: offsetHeight / getBoundingClientRect always return 0.
 *   `useVirtualizer` therefore computes zero total-size and renders 0 virtual rows
 *   unless we stub layout APIs. We apply a minimal stub (offsetHeight + getBCR) on
 *   the scroll container so the virtualizer sees a non-zero viewport and renders
 *   at least the overscan window.
 * - The "only a small window is mounted" assertion is best-effort under jsdom: we
 *   verify that fewer than all 5 000 treeitems are in the DOM.
 * - Interaction (ArrowDown scrolls virtualizer) and a11y (axe) are verified via
 *   the Storybook `run-story-tests` gate on the real browser surface.
 */
import { describe, it, expect, vi, beforeAll, afterAll } from "vitest";
import { render, screen, waitFor, act } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { Tree, type TreeNode } from "./tree";

// ---------------------------------------------------------------------------
// jsdom layout stubs for @tanstack/react-virtual
// ---------------------------------------------------------------------------

const VIEWPORT_HEIGHT = 400;
const ROW_HEIGHT = 32;

/**
 * Stub `offsetHeight` and `getBoundingClientRect` on any element that has the
 * data-virtual-scroll attribute, so the virtualizer computes a non-zero
 * viewport and renders rows. We patch at the Element prototype level so every
 * scroll container benefits.
 */
let originalGetBCR: () => DOMRect;

beforeAll(() => {
  originalGetBCR = Element.prototype.getBoundingClientRect;

  // Give every element a height. The virtualizer uses this for its scroll container.
  Object.defineProperty(HTMLElement.prototype, "offsetHeight", {
    configurable: true,
    get() {
      return VIEWPORT_HEIGHT;
    },
  });

  Element.prototype.getBoundingClientRect = function () {
    return {
      width: 300,
      height: VIEWPORT_HEIGHT,
      top: 0,
      left: 0,
      bottom: VIEWPORT_HEIGHT,
      right: 300,
      x: 0,
      y: 0,
      toJSON() {
        return this;
      },
    };
  };
});

afterAll(() => {
  Element.prototype.getBoundingClientRect = originalGetBCR;
  // Remove the accessor we installed by redefining with a plain value descriptor.
  // We cannot mix accessor (get/set) and data (value/writable) in one call —
  // so delete the property first, then reinstall as a data property (jsdom default).
  Object.defineProperty(HTMLElement.prototype, "offsetHeight", {
    configurable: true,
    get() {
      return 0;
    },
  });
});

// ---------------------------------------------------------------------------
// Fixtures
// ---------------------------------------------------------------------------

const nodes: TreeNode[] = [
  {
    id: "fruits",
    label: "Fruits",
    children: [
      { id: "apple", label: "Apple" },
      { id: "banana", label: "Banana" },
    ],
  },
  {
    id: "veggies",
    label: "Vegetables",
    children: [{ id: "carrot", label: "Carrot" }],
  },
];

// ---------------------------------------------------------------------------
// Existing non-virtualized tests (must stay green)
// ---------------------------------------------------------------------------

describe("Tree (non-virtualized)", () => {
  it("renders a tree with treeitems", () => {
    render(<Tree nodes={nodes} />);
    expect(screen.getByRole("tree")).toBeInTheDocument();
    expect(screen.getByRole("treeitem", { name: /Fruits/ })).toBeInTheDocument();
    expect(screen.getByRole("treeitem", { name: /Vegetables/ })).toBeInTheDocument();
  });

  it("collapses children by default (descendants are not rendered)", () => {
    render(<Tree nodes={nodes} />);
    expect(screen.queryByRole("treeitem", { name: /Apple/ })).not.toBeInTheDocument();
  });

  it("uses roving tabindex — exactly one treeitem is tabbable", () => {
    render(<Tree nodes={nodes} defaultExpandedIds={["fruits"]} />);
    const items = screen.getAllByRole("treeitem");
    const tabbable = items.filter((el) => el.getAttribute("tabindex") === "0");
    expect(tabbable).toHaveLength(1);
  });

  it("marks expanded parents with aria-expanded and renders their children", () => {
    render(<Tree nodes={nodes} defaultExpandedIds={["fruits"]} />);
    expect(screen.getByRole("treeitem", { name: /Fruits/ })).toHaveAttribute(
      "aria-expanded",
      "true",
    );
    expect(screen.getByRole("treeitem", { name: /Apple/ })).toBeInTheDocument();
  });

  it("exposes hierarchy semantics (aria-level / setsize / posinset)", () => {
    render(<Tree nodes={nodes} defaultExpandedIds={["fruits"]} />);
    const fruits = screen.getByRole("treeitem", { name: /Fruits/ });
    expect(fruits).toHaveAttribute("aria-level", "1");
    expect(fruits).toHaveAttribute("aria-setsize", "2");
    expect(fruits).toHaveAttribute("aria-posinset", "1");
    const apple = screen.getByRole("treeitem", { name: /Apple/ });
    expect(apple).toHaveAttribute("aria-level", "2");
  });

  it("toggles expansion when a parent row is clicked", async () => {
    const user = userEvent.setup();
    render(<Tree nodes={nodes} selectionMode="none" />);
    const fruits = screen.getByRole("treeitem", { name: /Fruits/ });
    expect(fruits).toHaveAttribute("aria-expanded", "false");
    await user.click(fruits);
    expect(fruits).toHaveAttribute("aria-expanded", "true");
    expect(screen.getByRole("treeitem", { name: /Apple/ })).toBeInTheDocument();
  });

  it("fires onSelectionChange and marks aria-selected on select", async () => {
    const user = userEvent.setup();
    const onSelectionChange = vi.fn();
    render(
      <Tree nodes={nodes} defaultExpandedIds={["fruits"]} onSelectionChange={onSelectionChange} />,
    );
    await user.click(screen.getByRole("treeitem", { name: /Apple/ }));
    expect(onSelectionChange).toHaveBeenCalledWith(["apple"]);
    expect(screen.getByRole("treeitem", { name: /Apple/ })).toHaveAttribute(
      "aria-selected",
      "true",
    );
  });

  it("moves the active item with ArrowDown (roving focus)", async () => {
    const user = userEvent.setup();
    render(<Tree nodes={nodes} defaultExpandedIds={["fruits"]} />);
    const fruits = screen.getByRole("treeitem", { name: /Fruits/ });
    fruits.focus();
    expect(fruits).toHaveAttribute("tabindex", "0");
    await user.keyboard("{ArrowDown}");
    const apple = screen.getByRole("treeitem", { name: /Apple/ });
    expect(apple).toHaveAttribute("tabindex", "0");
    expect(fruits).toHaveAttribute("tabindex", "-1");
  });

  it("collapses an expanded parent with ArrowLeft", async () => {
    const user = userEvent.setup();
    render(<Tree nodes={nodes} defaultExpandedIds={["fruits"]} />);
    const fruits = screen.getByRole("treeitem", { name: /Fruits/ });
    fruits.focus();
    await user.keyboard("{ArrowLeft}");
    expect(fruits).toHaveAttribute("aria-expanded", "false");
    expect(screen.queryByRole("treeitem", { name: /Apple/ })).not.toBeInTheDocument();
  });

  it("does not select disabled nodes", async () => {
    const user = userEvent.setup();
    const onSelectionChange = vi.fn();
    const withDisabled: TreeNode[] = [
      { id: "a", label: "Alpha", disabled: true },
      { id: "b", label: "Beta" },
    ];
    render(<Tree nodes={withDisabled} onSelectionChange={onSelectionChange} />);
    await user.click(screen.getByRole("treeitem", { name: /Alpha/ }));
    expect(onSelectionChange).not.toHaveBeenCalled();
  });
});

// ---------------------------------------------------------------------------
// Lazy loading tests
// ---------------------------------------------------------------------------

describe("Tree (lazy loading)", () => {
  function makeLazyNodes(): TreeNode[] {
    return [
      { id: "root-a", label: "Category A", hasChildren: true },
      { id: "root-b", label: "Category B" },
    ];
  }

  it("shows the expand affordance for hasChildren nodes even without loaded children", () => {
    render(<Tree nodes={makeLazyNodes()} />);
    const catA = screen.getByRole("treeitem", { name: /Category A/ });
    // aria-expanded should be present (false) because it's expandable
    expect(catA).toHaveAttribute("aria-expanded", "false");
  });

  it("calls loadChildren on first expand and shows loading state (aria-busy)", async () => {
    const user = userEvent.setup();
    let resolveLoad!: (nodes: TreeNode[]) => void;
    const loadChildren = vi.fn(
      () =>
        new Promise<TreeNode[]>((res) => {
          resolveLoad = res;
        }),
    );

    render(<Tree nodes={makeLazyNodes()} loadChildren={loadChildren} />);
    const catA = screen.getByRole("treeitem", { name: /Category A/ });

    await user.click(catA);

    // loadChildren must have been called
    expect(loadChildren).toHaveBeenCalledTimes(1);
    expect(loadChildren).toHaveBeenCalledWith(expect.objectContaining({ id: "root-a" }));

    // While loading, aria-busy is set on the parent treeitem
    await waitFor(() => {
      expect(screen.getByRole("treeitem", { name: /Category A/ })).toHaveAttribute(
        "aria-busy",
        "true",
      );
    });

    // Resolve the promise with children
    await act(async () => {
      resolveLoad([
        { id: "child-1", label: "Child 1" },
        { id: "child-2", label: "Child 2" },
      ]);
    });

    // Children should now be rendered
    await waitFor(() => {
      expect(screen.getByRole("treeitem", { name: /Child 1/ })).toBeInTheDocument();
      expect(screen.getByRole("treeitem", { name: /Child 2/ })).toBeInTheDocument();
    });

    // aria-busy should be cleared
    expect(screen.getByRole("treeitem", { name: /Category A/ })).not.toHaveAttribute("aria-busy");
  });

  it("does not call loadChildren again on re-expand (cached)", async () => {
    const user = userEvent.setup();
    const loadChildren = vi.fn().mockResolvedValue([{ id: "child-1", label: "Child 1" }]);

    render(<Tree nodes={makeLazyNodes()} loadChildren={loadChildren} />);
    const catA = screen.getByRole("treeitem", { name: /Category A/ });

    // First expand — triggers fetch
    await user.click(catA);
    await waitFor(() => {
      expect(screen.getByRole("treeitem", { name: /Child 1/ })).toBeInTheDocument();
    });
    expect(loadChildren).toHaveBeenCalledTimes(1);

    // Collapse
    await user.click(screen.getByRole("treeitem", { name: /Category A/ }));
    await waitFor(() => {
      expect(screen.queryByRole("treeitem", { name: /Child 1/ })).not.toBeInTheDocument();
    });

    // Re-expand — should NOT call loadChildren again
    await user.click(screen.getByRole("treeitem", { name: /Category A/ }));
    await waitFor(() => {
      expect(screen.getByRole("treeitem", { name: /Child 1/ })).toBeInTheDocument();
    });
    expect(loadChildren).toHaveBeenCalledTimes(1);
  });

  it("shows error state and retry button when loadChildren rejects", async () => {
    const user = userEvent.setup();
    const loadChildren = vi.fn().mockRejectedValue(new Error("Network error"));

    render(<Tree nodes={makeLazyNodes()} loadChildren={loadChildren} />);
    const catA = screen.getByRole("treeitem", { name: /Category A/ });

    await user.click(catA);

    // Error state: "Failed to load" text visible, no crash
    await waitFor(() => {
      expect(screen.getByText(/Failed to load/i)).toBeInTheDocument();
    });
    expect(screen.getByRole("button", { name: /retry/i })).toBeInTheDocument();

    // aria-busy is NOT set in error state (it's cleared)
    expect(screen.getByRole("treeitem", { name: /Category A/ })).not.toHaveAttribute("aria-busy");
  });

  it("retries successfully after error", async () => {
    const user = userEvent.setup();
    const loadChildren = vi
      .fn()
      .mockRejectedValueOnce(new Error("fail"))
      .mockResolvedValue([{ id: "retry-child", label: "Retry Child" }]);

    render(<Tree nodes={makeLazyNodes()} loadChildren={loadChildren} />);
    await user.click(screen.getByRole("treeitem", { name: /Category A/ }));

    await waitFor(() => expect(screen.getByRole("button", { name: /retry/i })).toBeInTheDocument());

    await user.click(screen.getByRole("button", { name: /retry/i }));

    await waitFor(() => {
      expect(screen.getByRole("treeitem", { name: /Retry Child/ })).toBeInTheDocument();
    });
  });
});

// ---------------------------------------------------------------------------
// Virtualization tests
// ---------------------------------------------------------------------------

describe("Tree (virtualized)", () => {
  function build(count: number): TreeNode[] {
    return Array.from({ length: count }, (_, i) => ({ id: `n-${i}`, label: `Node ${i + 1}` }));
  }

  it("renders a scroll container and the role=tree root when virtualize=true", () => {
    render(
      <Tree nodes={build(5000)} virtualize maxHeight="400px" estimateRowHeight={ROW_HEIGHT} />,
    );
    expect(screen.getByRole("tree")).toBeInTheDocument();
  });

  it("renders far fewer than 5 000 treeitems in the DOM (windowing is active)", () => {
    // Environment note: jsdom layout is stubbed above so the virtualizer can
    // compute a non-zero window. The exact rendered count depends on the stub
    // heights but should always be ≪ 5 000.
    render(
      <Tree nodes={build(5000)} virtualize maxHeight="400px" estimateRowHeight={ROW_HEIGHT} />,
    );
    const items = screen.queryAllByRole("treeitem");
    // Expect far fewer than all 5000 nodes in the DOM.
    // Under the jsdom stub (400px viewport / 32px rows = ~12–26 with overscan).
    expect(items.length).toBeLessThan(100);
    expect(items.length).toBeGreaterThan(0);
  });

  it("carries correct ARIA attributes on virtual rows (level / setsize / posinset)", () => {
    const smallNodes = build(20);
    render(<Tree nodes={smallNodes} virtualize maxHeight="400px" estimateRowHeight={ROW_HEIGHT} />);
    // First rendered item should be node-0 at level 1, setsize 20, posinset 1
    const first = screen.getByRole("treeitem", { name: "Node 1" });
    expect(first).toHaveAttribute("aria-level", "1");
    expect(first).toHaveAttribute("aria-setsize", "20");
    expect(first).toHaveAttribute("aria-posinset", "1");
  });

  it("ArrowDown moves active tabindex in the virtual flat list", async () => {
    const user = userEvent.setup();
    const smallNodes = build(30);
    render(<Tree nodes={smallNodes} virtualize maxHeight="400px" estimateRowHeight={ROW_HEIGHT} />);

    const first = screen.getByRole("treeitem", { name: "Node 1" });
    first.focus();
    expect(first).toHaveAttribute("tabindex", "0");

    await user.keyboard("{ArrowDown}");

    const second = screen.getByRole("treeitem", { name: "Node 2" });
    expect(second).toHaveAttribute("tabindex", "0");
    expect(first).toHaveAttribute("tabindex", "-1");
  });

  it("selects a node on click in virtual mode", async () => {
    const user = userEvent.setup();
    const onSelectionChange = vi.fn();
    const smallNodes = build(20);
    render(
      <Tree
        nodes={smallNodes}
        virtualize
        maxHeight="400px"
        estimateRowHeight={ROW_HEIGHT}
        onSelectionChange={onSelectionChange}
      />,
    );
    await user.click(screen.getByRole("treeitem", { name: "Node 3" }));
    expect(onSelectionChange).toHaveBeenCalledWith(["n-2"]);
  });
});
