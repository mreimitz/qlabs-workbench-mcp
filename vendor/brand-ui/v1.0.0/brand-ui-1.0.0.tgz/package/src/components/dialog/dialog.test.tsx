import { describe, it, expect } from "vitest";
import { render, screen } from "@testing-library/react";
import { Dialog, DialogContent, DialogTitle, DialogDescription } from "./dialog";

function Wrapper({ size }: { size?: "sm" | "lg" | "xl" | "full" }) {
  return (
    <Dialog open>
      <DialogContent size={size}>
        <DialogTitle>Test dialog</DialogTitle>
        <DialogDescription>Test description</DialogDescription>
        Content
      </DialogContent>
    </Dialog>
  );
}

describe("DialogContent size variants", () => {
  it("default (no size prop) renders max-w-lg — regression lock", () => {
    render(<Wrapper />);
    const content = screen.getByRole("dialog");
    expect(content.className).toContain("max-w-lg");
  });

  it("size='lg' renders max-w-lg", () => {
    render(<Wrapper size="lg" />);
    const content = screen.getByRole("dialog");
    expect(content.className).toContain("max-w-lg");
  });

  it("size='sm' renders max-w-sm", () => {
    render(<Wrapper size="sm" />);
    const content = screen.getByRole("dialog");
    expect(content.className).toContain("max-w-sm");
  });

  it("size='xl' renders max-w-3xl", () => {
    render(<Wrapper size="xl" />);
    const content = screen.getByRole("dialog");
    expect(content.className).toContain("max-w-3xl");
  });

  it("size='full' renders max-w-[95vw] and h-[90vh]", () => {
    render(<Wrapper size="full" />);
    const content = screen.getByRole("dialog");
    expect(content.className).toContain("max-w-[95vw]");
    expect(content.className).toContain("h-[90vh]");
  });
});
