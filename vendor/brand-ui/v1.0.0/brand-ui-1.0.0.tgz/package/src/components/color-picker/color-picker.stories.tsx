import type { Meta, StoryObj } from "@storybook/react-vite";
import { useState } from "react";
import { ColorPicker } from "./color-picker";

const meta = {
  title: "Forms/ColorPicker",
  component: ColorPicker,
  tags: ["autodocs"],
} satisfies Meta<typeof ColorPicker>;
export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {
  args: { defaultValue: "chart-1" },
};

export const Controlled: Story = {
  render: () => {
    // eslint-disable-next-line react-hooks/rules-of-hooks
    const [color, setColor] = useState<string>("primary");
    return (
      <div className="flex flex-col gap-2">
        <ColorPicker value={color} onValueChange={setColor} />
        <p className="text-sm text-muted-foreground">Selected: {color}</p>
      </div>
    );
  },
};

export const ChartTokensOnly: Story = {
  args: {
    defaultValue: "chart-1",
    swatches: ["chart-1", "chart-2", "chart-3", "chart-4", "chart-5"],
  },
};

export const WithCustomHex: Story = {
  args: { defaultValue: "primary", allowCustom: true },
};

export const StatusTokens: Story = {
  args: {
    defaultValue: "success",
    swatches: ["success", "warning", "destructive", "info"],
  },
};
