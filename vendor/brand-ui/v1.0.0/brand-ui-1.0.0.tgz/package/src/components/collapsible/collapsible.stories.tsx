import type { Meta, StoryObj } from "@storybook/react-vite";
import { Button } from "../button";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "./collapsible";
const meta = {
  title: "Disclosure/Collapsible",
  component: Collapsible,
  tags: ["autodocs"],
} satisfies Meta<typeof Collapsible>;
export default meta;
type Story = StoryObj<typeof meta>;
export const Default: Story = {
  render: () => (
    <Collapsible className="w-80 space-y-2">
      <CollapsibleTrigger asChild>
        <Button variant="outline" size="sm">
          Toggle details
        </Button>
      </CollapsibleTrigger>
      <CollapsibleContent className="rounded-md border p-3 text-sm text-muted-foreground">
        Hidden details revealed.
      </CollapsibleContent>
    </Collapsible>
  ),
};
