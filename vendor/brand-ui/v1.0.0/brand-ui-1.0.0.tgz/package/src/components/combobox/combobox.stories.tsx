import type { Meta, StoryObj } from "@storybook/react-vite";
import { Combobox } from "./combobox";
const meta = { title: "Forms/Combobox", component: Combobox, tags: ["autodocs"] } satisfies Meta<
  typeof Combobox
>;
export default meta;
type Story = StoryObj<typeof meta>;
export const Default: Story = {
  args: {
    options: [
      { label: "Production", value: "prod" },
      { label: "Staging", value: "staging" },
      { label: "Development", value: "dev" },
    ],
    placeholder: "Select environment…",
  },
};
