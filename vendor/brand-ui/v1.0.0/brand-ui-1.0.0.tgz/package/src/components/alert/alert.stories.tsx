import type { Meta, StoryObj } from "@storybook/react-vite";
import { AlertTriangle, Info } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "./alert";
const meta = { title: "States/Alert", component: Alert, tags: ["autodocs"] } satisfies Meta<
  typeof Alert
>;
export default meta;
type Story = StoryObj<typeof meta>;
export const Info_: Story = {
  name: "Info",
  render: () => (
    <Alert variant="info" className="max-w-md">
      <Info />
      <AlertTitle>Heads up</AlertTitle>
      <AlertDescription>This deploy includes a schema migration.</AlertDescription>
    </Alert>
  ),
};
export const Destructive: Story = {
  render: () => (
    <Alert variant="destructive" className="max-w-md">
      <AlertTriangle />
      <AlertTitle>Error</AlertTitle>
      <AlertDescription>Your session has expired.</AlertDescription>
    </Alert>
  ),
};
