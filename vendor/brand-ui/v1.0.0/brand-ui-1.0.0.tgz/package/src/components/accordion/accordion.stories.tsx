import type { Meta, StoryObj } from "@storybook/react-vite";
import { expect } from "storybook/test";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "./accordion";
const meta = {
  title: "Disclosure/Accordion",
  component: Accordion,
  tags: ["autodocs"],
} satisfies Meta<typeof Accordion>;
export default meta;
type Story = StoryObj<typeof meta>;
export const Default: Story = {
  render: () => (
    <Accordion type="single" collapsible className="w-80">
      <AccordionItem value="a">
        <AccordionTrigger>What is brand-ui?</AccordionTrigger>
        <AccordionContent>A token-driven component system.</AccordionContent>
      </AccordionItem>
      <AccordionItem value="b">
        <AccordionTrigger>Is it themeable?</AccordionTrigger>
        <AccordionContent>Yes — via data-theme tokens.</AccordionContent>
      </AccordionItem>
    </Accordion>
  ),
  // Expanding an item flips its trigger to aria-expanded and mounts the panel
  // content (Radix keeps closed panels out of the DOM).
  play: async ({ canvas, userEvent }) => {
    const trigger = canvas.getByRole("button", { name: "What is brand-ui?" });
    await expect(trigger).toHaveAttribute("aria-expanded", "false");
    await userEvent.click(trigger);
    await expect(trigger).toHaveAttribute("aria-expanded", "true");
    await expect(await canvas.findByText("A token-driven component system.")).toBeVisible();
  },
};
