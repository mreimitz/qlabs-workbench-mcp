import type { Meta, StoryObj } from "@storybook/react-vite";
import { useState } from "react";
import { NumberInput } from "./number-input";

const meta = {
  title: "Forms/NumberInput",
  component: NumberInput,
  tags: ["autodocs"],
  args: { step: 1 },
} satisfies Meta<typeof NumberInput>;
export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {
  args: { defaultValue: 5, min: 0, max: 10 },
};

export const Controlled: Story = {
  render: () => {
    // eslint-disable-next-line react-hooks/rules-of-hooks
    const [value, setValue] = useState<number | null>(3);
    return (
      <div className="flex flex-col gap-2">
        <NumberInput value={value} onValueChange={setValue} min={0} max={20} />
        <p className="text-sm text-muted-foreground">Value: {value ?? "empty"}</p>
      </div>
    );
  },
};

export const WithFormatOptions: Story = {
  args: {
    defaultValue: 1234.5,
    formatOptions: { style: "currency", currency: "USD" },
    step: 100,
  },
};

export const NoClamp: Story = {
  args: { defaultValue: 5, min: 0, max: 10, clamp: false },
};

export const Disabled: Story = {
  args: { defaultValue: 5, disabled: true },
};

export const WithBounds: Story = {
  args: { defaultValue: 0, min: 0, max: 100, step: 10 },
};
