import type { Meta, StoryObj } from "@storybook/react";
import { useState } from "react";
import { Wizard, WizardSteps, WizardStep, WizardNav, type WizardStepMeta } from "./wizard";

const meta = {
  title: "Navigation/Wizard",
  component: Wizard,
  tags: ["autodocs"],
} satisfies Meta<typeof Wizard>;

export default meta;
type Story = StoryObj<typeof meta>;

const steps: WizardStepMeta[] = [
  { id: "account", title: "Account", description: "Login details" },
  { id: "profile", title: "Profile", description: "About you" },
  { id: "review", title: "Review", description: "Confirm" },
];

const Panel = ({ children }: { children: React.ReactNode }) => (
  <div className="rounded-md border border-border bg-card p-4 text-card-foreground">{children}</div>
);

export const Default: Story = {
  render: () => (
    <Wizard steps={steps} className="max-w-xl">
      <WizardSteps />
      <WizardStep step={0}>
        <Panel>Step 1 — account details.</Panel>
      </WizardStep>
      <WizardStep step={1}>
        <Panel>Step 2 — profile details.</Panel>
      </WizardStep>
      <WizardStep step={2}>
        <Panel>Step 3 — review and confirm.</Panel>
      </WizardStep>
      <WizardNav onFinish={() => alert("Finished!")} />
    </Wizard>
  ),
};

export const Vertical: Story = {
  render: () => (
    <Wizard steps={steps} orientation="vertical" className="max-w-2xl">
      <WizardSteps />
      <div className="flex flex-1 flex-col gap-4">
        <WizardStep step={0}>
          <Panel>Account details.</Panel>
        </WizardStep>
        <WizardStep step={1}>
          <Panel>Profile details.</Panel>
        </WizardStep>
        <WizardStep step={2}>
          <Panel>Review.</Panel>
        </WizardStep>
        <WizardNav />
      </div>
    </Wizard>
  ),
};

export const WithValidationGating: Story = {
  render: () => {
    // eslint-disable-next-line react-hooks/rules-of-hooks
    const [agreed, setAgreed] = useState(false);
    return (
      <Wizard steps={steps} className="max-w-xl">
        <WizardSteps />
        <WizardStep step={0} validate={() => agreed}>
          <Panel>
            <label className="flex items-center gap-2">
              <input
                type="checkbox"
                checked={agreed}
                onChange={(e) => setAgreed(e.target.checked)}
              />
              I agree to continue (Next is blocked until checked).
            </label>
          </Panel>
        </WizardStep>
        <WizardStep step={1}>
          <Panel>Profile details.</Panel>
        </WizardStep>
        <WizardStep step={2}>
          <Panel>Review.</Panel>
        </WizardStep>
        <WizardNav />
      </Wizard>
    );
  },
};
