import { useState } from "react";
import type { Meta, StoryObj } from "@storybook/react-vite";
import { Transfer } from "./transfer";
import type { TransferItem } from "./transfer";

const PEOPLE: TransferItem[] = [
  { value: "alice", label: "Alice Okafor" },
  { value: "bob", label: "Bob Chen" },
  { value: "carol", label: "Carol Singh" },
  { value: "david", label: "David Müller" },
  { value: "eve", label: "Eve Nakamura" },
  { value: "frank", label: "Frank Johansson" },
  { value: "grace", label: "Grace Andersen" },
  { value: "hana", label: "Hana Petrov" },
];

const PERMISSIONS: TransferItem[] = [
  { value: "read", label: "Read" },
  { value: "write", label: "Write" },
  { value: "delete", label: "Delete", disabled: true },
  { value: "admin", label: "Admin", disabled: true },
  { value: "export", label: "Export" },
  { value: "import", label: "Import" },
];

const meta = {
  title: "Components/Transfer",
  component: Transfer,
  tags: ["autodocs"],
  parameters: { layout: "padded" },
  args: {
    dataSource: PEOPLE,
    defaultTargetKeys: ["carol", "eve"],
    titles: ["Available", "Selected"],
  },
} satisfies Meta<typeof Transfer>;

export default meta;
type Story = StoryObj<typeof meta>;

/** Default uncontrolled transfer with pre-selected items. */
export const Default: Story = {};

/** With per-panel search inputs. */
export const WithSearch: Story = {
  args: {
    showSearch: true,
    dataSource: PEOPLE,
    defaultTargetKeys: ["alice", "bob"],
  },
};

/** Controlled — parent owns the target key list. */
export const Controlled: Story = {
  render: () => {
    function ControlledExample() {
      const [targetKeys, setTargetKeys] = useState(["read", "export"]);
      return (
        <div className="flex flex-col gap-4">
          <Transfer
            dataSource={PERMISSIONS}
            targetKeys={targetKeys}
            onChange={setTargetKeys}
            titles={["Available permissions", "Granted permissions"]}
          />
          <p className="text-sm text-muted-foreground">
            Granted: {targetKeys.join(", ") || "(none)"}
          </p>
        </div>
      );
    }
    return <ControlledExample />;
  },
};

/** Some items are disabled and cannot be moved. */
export const DisabledItems: Story = {
  args: {
    dataSource: PERMISSIONS,
    defaultTargetKeys: ["read"],
    titles: ["Available permissions", "Granted permissions"],
  },
};

/** Empty dataSource — both panels show the empty state. */
export const Empty: Story = {
  args: {
    dataSource: [],
    defaultTargetKeys: [],
  },
};

/** Custom panel titles. */
export const CustomTitles: Story = {
  args: {
    titles: ["Team members", "Reviewers"],
    dataSource: PEOPLE,
    defaultTargetKeys: ["grace", "hana"],
  },
};
