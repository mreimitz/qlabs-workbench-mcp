import type { Meta, StoryObj } from "@storybook/react-vite";
import { expect, userEvent } from "storybook/test";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "./card";

const meta = {
  title: "Foundation/Card",
  component: Card,
  tags: ["autodocs"],
} satisfies Meta<typeof Card>;
export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {
  render: () => (
    <Card className="max-w-sm">
      <CardHeader>
        <CardTitle>Monthly active users</CardTitle>
        <CardDescription>Across all workspaces</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="text-3xl font-semibold">24,512</div>
      </CardContent>
      <CardFooter>
        <span className="text-sm text-muted-foreground">+12.4% vs last month</span>
      </CardFooter>
    </Card>
  ),
};

/** Opt-in hover-lift for clickable cards (gated by the motion system). */
export const Interactive: Story = {
  render: () => (
    <Card interactive className="max-w-sm" tabIndex={0} role="button">
      <CardHeader>
        <CardTitle>Production pipeline</CardTitle>
        <CardDescription>Hover or focus — lifts over the gated duration</CardDescription>
      </CardHeader>
      <CardContent>
        <span className="text-sm text-muted-foreground">Last run 4m ago · 1.2M rows</span>
      </CardContent>
    </Card>
  ),
  play: async ({ canvas }) => {
    const card = canvas.getByRole("button");
    const cs = getComputedStyle(card);
    // The lift uses Tailwind v4's standalone `translate` property — the
    // transition MUST list `translate` (not the `transform` shorthand) or it
    // snaps instead of gliding. Guards against the v4 transform-split gotcha.
    await expect(cs.transitionProperty).toContain("translate");
    await expect(parseFloat(cs.transitionDuration)).toBeGreaterThanOrEqual(0.2); // gated --t-base
  },
};

// ---------------------------------------------------------------------------
// Detail panel stories (#118 DP-01)
// Each story is wrapped in a sized parent so the grid layout has a defined
// height/width to work with (side panels need a concrete height).
// ---------------------------------------------------------------------------

/** Side panel always visible (default detailReveal). */
export const DetailSideFixed: Story = {
  render: () => (
    <div className="h-64 w-[480px]">
      <Card
        className="h-full"
        detail={
          <div className="flex flex-col gap-2">
            <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">
              Metadata
            </p>
            <ul className="text-sm text-foreground space-y-1">
              <li className="flex justify-between">
                <span className="text-muted-foreground">Owner</span>
                <span>analytics-team</span>
              </li>
              <li className="flex justify-between">
                <span className="text-muted-foreground">Updated</span>
                <span>2 days ago</span>
              </li>
              <li className="flex justify-between">
                <span className="text-muted-foreground">Rows</span>
                <span>1.2M</span>
              </li>
            </ul>
          </div>
        }
        detailPlacement="side"
        detailReveal="fixed"
      >
        <CardHeader>
          <CardTitle>Sales pipeline</CardTitle>
          <CardDescription>Q2 2026 opportunities</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="text-3xl font-semibold">$4.7M</div>
        </CardContent>
      </Card>
    </div>
  ),
};

/** Side panel revealed on hover / keyboard focus-within (outer card size stays constant). */
export const DetailSideHover: Story = {
  render: () => (
    <div className="h-64 w-[480px]">
      <Card
        className="h-full"
        detail={
          <div className="flex flex-col gap-2">
            <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">
              Quick actions
            </p>
            <ul className="text-sm space-y-1">
              <li>
                <button className="text-foreground hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring rounded-sm px-1">
                  View report
                </button>
              </li>
              <li>
                <button className="text-foreground hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring rounded-sm px-1">
                  Export CSV
                </button>
              </li>
              <li>
                <button className="text-foreground hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring rounded-sm px-1">
                  Share
                </button>
              </li>
            </ul>
          </div>
        }
        detailPlacement="side"
        detailReveal="hover"
      >
        <CardHeader>
          <CardTitle>Revenue report</CardTitle>
          <CardDescription>Hover or tab into the card to reveal actions</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="text-3xl font-semibold">$182K</div>
        </CardContent>
      </Card>
    </div>
  ),
};

/** Bottom panel always visible. */
export const DetailBottomFixed: Story = {
  render: () => (
    <div className="h-80 w-96">
      <Card
        className="h-full"
        detail={
          <div className="flex items-center gap-4">
            <span className="text-sm text-muted-foreground">Last synced 5 min ago</span>
            <span className="ms-auto rounded-full bg-surface px-2 py-0.5 text-xs border border-border text-foreground">
              Live
            </span>
          </div>
        }
        detailPlacement="bottom"
        detailReveal="fixed"
        detailSize="3.5rem"
      >
        <CardHeader>
          <CardTitle>Active sessions</CardTitle>
          <CardDescription>Across all regions</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="text-3xl font-semibold">8,340</div>
        </CardContent>
      </Card>
    </div>
  ),
};

/** Bottom panel revealed on hover / keyboard focus-within. */
export const DetailBottomHover: Story = {
  render: () => (
    <div className="h-80 w-96">
      <Card
        className="h-full"
        detail={
          <div className="flex items-center gap-3">
            <button className="text-sm text-foreground hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring rounded-sm px-1">
              Drill down
            </button>
            <button className="text-sm text-foreground hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring rounded-sm px-1">
              Download
            </button>
          </div>
        }
        detailPlacement="bottom"
        detailReveal="hover"
        detailSize="3rem"
      >
        <CardHeader>
          <CardTitle>Ingest volume</CardTitle>
          <CardDescription>Hover to reveal bottom actions</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="text-3xl font-semibold">94 GB/hr</div>
        </CardContent>
      </Card>
    </div>
  ),
};

/** Proves `interactive` (hover-lift) and `detail` panel coexist without conflict. */
export const InteractiveWithDetail: Story = {
  render: () => (
    <div className="h-64 w-[480px]">
      <Card
        className="h-full"
        interactive
        tabIndex={0}
        role="button"
        detail={
          <div className="flex flex-col gap-2">
            <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">
              Details
            </p>
            <ul className="text-sm space-y-1">
              <li className="flex justify-between">
                <span className="text-muted-foreground">Status</span>
                <span className="text-foreground">Healthy</span>
              </li>
              <li className="flex justify-between">
                <span className="text-muted-foreground">SLA</span>
                <span className="text-foreground">99.9%</span>
              </li>
            </ul>
          </div>
        }
        detailPlacement="side"
        detailReveal="fixed"
      >
        <CardHeader>
          <CardTitle>Data pipeline</CardTitle>
          <CardDescription>Interactive card with a fixed side panel</CardDescription>
        </CardHeader>
        <CardContent>
          <span className="text-sm text-muted-foreground">
            Hover to lift · detail always visible
          </span>
        </CardContent>
      </Card>
    </div>
  ),
  play: async ({ canvas }) => {
    const card = canvas.getByRole("button");
    // Both interactive lift AND detail panel are rendered — card is in the DOM.
    await expect(card).toBeInTheDocument();
    const cs = getComputedStyle(card);
    await expect(cs.transitionProperty).toContain("translate");
  },
};

/**
 * Keyboard path: tab into a side+hover card and assert the detail's focusable
 * control is reachable. The `focus-within` CSS selector reveals the panel; DOM
 * assertions confirm the control is present and accessible (layout is opaque to
 * jsdom so we verify focusability, not visual appearance).
 */
export const DetailHoverKeyboardReveal: Story = {
  render: () => (
    <div className="h-64 w-[480px]">
      {/* Sentinel button before the card so Tab lands inside the card next */}
      <button className="sr-only" data-testid="before-sentinel">
        Before card
      </button>
      <Card
        className="h-full"
        detail={
          <div className="flex flex-col gap-2 pt-1">
            <button
              data-testid="detail-action"
              className="text-sm text-foreground hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring rounded-sm px-1 text-start"
            >
              Open details
            </button>
          </div>
        }
        detailPlacement="side"
        detailReveal="hover"
      >
        <CardHeader>
          <CardTitle>Keyboard reveal demo</CardTitle>
          <CardDescription>Tab into the card — focus-within opens the panel</CardDescription>
        </CardHeader>
        <CardContent>
          <span className="text-sm text-muted-foreground">Press Tab to navigate in</span>
        </CardContent>
      </Card>
    </div>
  ),
  play: async ({ canvas }) => {
    // The detail button stays in the DOM even when the panel is visually collapsed
    // (overflow-hidden clips it; display:none is NOT used so AT reaches it).
    const detailBtn = canvas.getByTestId("detail-action");
    await expect(detailBtn).toBeInTheDocument();

    // Drive the keyboard path: focus the sentinel, then Tab to move into the card.
    const sentinel = canvas.getByTestId("before-sentinel");
    sentinel.focus();

    // Tab through focusable elements inside the card until we reach the detail button.
    const user = userEvent.setup({ delay: null });
    // Tab once to enter the card area (the first tabbable element inside).
    await user.tab();

    // The detail button is always in the DOM (clipped, not removed), so focus can
    // reach it via Tab — assert it is focusable and present.
    await expect(detailBtn).toBeInTheDocument();
    // Tab until we land on the detail button (at most a few extra tabs).
    let attempts = 0;
    while (document.activeElement !== detailBtn && attempts < 6) {
      await user.tab();
      attempts++;
    }
    await expect(document.activeElement).toBe(detailBtn);
  },
};
