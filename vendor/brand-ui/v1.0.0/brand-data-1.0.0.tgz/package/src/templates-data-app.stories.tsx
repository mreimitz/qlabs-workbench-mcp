/**
 * Story for the registry/templates/data-app template.
 * Shows the full data-app page: app-shell + DataTable with toolbar.
 * Verify across all six themes with globals=theme:<slug>.
 */
import type { Meta, StoryObj } from "@storybook/react-vite";
import { useState } from "react";
import {
  Badge,
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarHeader,
  SidebarInset,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarProvider,
  SidebarTrigger,
} from "@brand/ui";
import { ColumnPicker, DataTable, FilterBar, SearchInput, type ColumnDef } from "./index";

type Status = "active" | "paused" | "error";

interface DataRow {
  id: string;
  name: string;
  status: Status;
  records: number;
  lastRun: string;
}

const statusVariant: Record<Status, "success" | "secondary" | "destructive"> = {
  active: "success",
  paused: "secondary",
  error: "destructive",
};

const columns: ColumnDef<DataRow>[] = [
  { accessorKey: "name", header: "Name" },
  {
    accessorKey: "status",
    header: "Status",
    cell: ({ row }) => (
      <Badge variant={statusVariant[row.original.status]}>{row.original.status}</Badge>
    ),
  },
  {
    accessorKey: "records",
    header: "Records",
    cell: ({ row }) => (
      <span className="tabular-nums">{row.original.records.toLocaleString()}</span>
    ),
  },
  { accessorKey: "lastRun", header: "Last run" },
];

const sampleData: DataRow[] = [
  { id: "1", name: "Customer import", status: "active", records: 14200, lastRun: "2 min ago" },
  { id: "2", name: "Nightly sync", status: "active", records: 88541, lastRun: "6 h ago" },
  { id: "3", name: "Legacy migration", status: "paused", records: 3010, lastRun: "3 d ago" },
  { id: "4", name: "Partner feed", status: "error", records: 0, lastRun: "1 d ago" },
];

const nav = [
  { id: "data", label: "Data" },
  { id: "tables", label: "Tables" },
  { id: "home", label: "Home" },
  { id: "settings", label: "Settings" },
];

function DataAppTemplate() {
  const [active, setActive] = useState("data");
  const [search, setSearch] = useState("");
  return (
    <SidebarProvider>
      <Sidebar collapsible="offcanvas">
        <SidebarHeader className="px-3 py-2 font-semibold">Acme Data</SidebarHeader>
        <SidebarContent>
          <SidebarGroup>
            <SidebarGroupContent>
              <SidebarMenu>
                {nav.map((n) => (
                  <SidebarMenuItem key={n.id}>
                    <SidebarMenuButton
                      isActive={active === n.id}
                      tooltip={n.label}
                      onClick={() => setActive(n.id)}
                    >
                      <span>{n.label}</span>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                ))}
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        </SidebarContent>
      </Sidebar>
      <SidebarInset>
        <header className="flex h-14 items-center gap-2 border-b px-4">
          <SidebarTrigger />
          <h1 className="text-sm font-medium capitalize">{active}</h1>
        </header>
        <main className="p-6">
          <DataTable
            columns={columns}
            data={sampleData}
            enablePagination
            toolbar={(table) => {
              table.setGlobalFilter(search);
              return (
                <FilterBar actions={<ColumnPicker table={table} />}>
                  <SearchInput value={search} onValueChange={setSearch} />
                </FilterBar>
              );
            }}
          />
        </main>
      </SidebarInset>
    </SidebarProvider>
  );
}

const meta = {
  title: "Templates/Data App",
  parameters: { layout: "fullscreen" },
  tags: ["autodocs"],
} satisfies Meta;
export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = { render: () => <DataAppTemplate /> };
