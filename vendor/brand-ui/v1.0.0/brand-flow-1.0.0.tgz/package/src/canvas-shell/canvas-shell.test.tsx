import { cleanup, render } from "@testing-library/react";
import { afterEach, describe, expect, it, vi } from "vitest";

// @xyflow/react requires real layout/measurement — mock the engine and assert
// the brand wrapper's own output. Real rendering + a11y are covered by Storybook
// interaction tests.
vi.mock("@xyflow/react", () => {
  // eslint-disable-next-line @typescript-eslint/no-require-imports -- a vi.mock factory is hoisted above imports; a lazy require avoids the TDZ a top-level import would hit
  const React = require("react");
  return {
    ReactFlow: ({ children, className }: { children?: React.ReactNode; className?: string }) =>
      React.createElement("div", { "data-testid": "react-flow", className }, children),
    Background: () => React.createElement("div", { "data-testid": "rf-background" }),
    ReactFlowProvider: ({ children }: { children?: React.ReactNode }) =>
      React.createElement("div", {}, children),
  };
});

import { CanvasShell } from "./canvas-shell";

afterEach(cleanup);

describe("CanvasShell", () => {
  it("renders without throwing", () => {
    const { container } = render(<CanvasShell nodes={[]} edges={[]} />);
    expect(container.firstChild).toBeInTheDocument();
  });

  it("renders the inner ReactFlow mock", () => {
    const { getByTestId } = render(<CanvasShell nodes={[]} edges={[]} />);
    expect(getByTestId("react-flow")).toBeInTheDocument();
  });

  it("renders the Background when background prop is true (default)", () => {
    const { getByTestId } = render(<CanvasShell nodes={[]} edges={[]} />);
    expect(getByTestId("rf-background")).toBeInTheDocument();
  });

  it("omits the Background when background={false}", () => {
    const { queryByTestId } = render(<CanvasShell nodes={[]} edges={[]} background={false} />);
    expect(queryByTestId("rf-background")).not.toBeInTheDocument();
  });

  it("applies custom className to the wrapper div", () => {
    const { container } = render(<CanvasShell nodes={[]} edges={[]} className="my-canvas" />);
    expect(container.firstChild).toHaveClass("my-canvas");
  });

  it("renders children inside the flow", () => {
    const { getByTestId } = render(
      <CanvasShell nodes={[]} edges={[]}>
        <div data-testid="child-panel">child</div>
      </CanvasShell>,
    );
    expect(getByTestId("child-panel")).toBeInTheDocument();
  });
});
