import { type ReactNode } from "react";
import { Background, ReactFlow, type Edge, type Node, type ReactFlowProps } from "@xyflow/react";
import { cn } from "@brand/ui/lib/cn";

export interface CanvasShellProps<
  NodeType extends Node = Node,
  EdgeType extends Edge = Edge,
> extends ReactFlowProps<NodeType, EdgeType> {
  /** Render a branded dotted background grid. Defaults to true. */
  background?: boolean;
  /** Overlays rendered inside the flow (ZoomControls, Legend, Panels). */
  children?: ReactNode;
  className?: string;
}

/**
 * Branded React Flow canvas. Sets a token-driven background + sensible
 * defaults; pass nodes/edges/handlers through as normal React Flow props.
 *
 * Consumers MUST import the React Flow stylesheet once at the app root:
 *   import "@xyflow/react/dist/style.css";
 *
 * Children render inside the flow context, so <ZoomControls /> and React Flow
 * <Panel>s work when placed here.
 */
export function CanvasShell<NodeType extends Node = Node, EdgeType extends Edge = Edge>({
  background = true,
  children,
  className,
  ...props
}: CanvasShellProps<NodeType, EdgeType>) {
  return (
    <div className={cn("h-full w-full bg-canvas", className)}>
      <ReactFlow fitView proOptions={{ hideAttribution: false }} {...props}>
        {background ? <Background gap={20} size={1} color="var(--canvas-grid)" /> : null}
        {children}
      </ReactFlow>
    </div>
  );
}
