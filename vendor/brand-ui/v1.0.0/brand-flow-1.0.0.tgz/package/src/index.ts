/**
 * @brand/flow — branded React Flow (@xyflow/react) building blocks.
 *
 * Import the React Flow stylesheet once at the app root:
 *   import "@xyflow/react/dist/style.css";
 */
export * from "./canvas-shell";
export * from "./flow-node";
export * from "./flow-edge";
export * from "./inspector-panel";
export * from "./legend";
export * from "./zoom-controls";

// Convenience re-exports so consumers can build flows without a direct dep.
export {
  Background,
  Controls,
  MiniMap,
  Panel,
  Position,
  ReactFlow,
  ReactFlowProvider,
  useReactFlow,
  useNodesState,
  useEdgesState,
  addEdge,
} from "@xyflow/react";
export type { Node, Edge, Connection, NodeProps, EdgeProps } from "@xyflow/react";
