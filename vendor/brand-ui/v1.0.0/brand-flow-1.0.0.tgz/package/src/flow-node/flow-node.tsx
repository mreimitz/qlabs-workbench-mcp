import { type ReactNode } from "react";
import { Handle, Position, type Node, type NodeProps } from "@xyflow/react";
import { cn } from "@brand/ui/lib/cn";

export interface FlowNodeData extends Record<string, unknown> {
  title: string;
  subtitle?: string;
  /** Short type label shown as an eyebrow, e.g. "Source", "Transform". */
  kind?: string;
  icon?: ReactNode;
  tone?: "default" | "accent" | "success" | "warning" | "destructive";
}

export type BrandFlowNode = Node<FlowNodeData, "brand">;

const toneRing: Record<NonNullable<FlowNodeData["tone"]>, string> = {
  default: "border-border",
  accent: "border-primary",
  success: "border-success",
  warning: "border-warning",
  destructive: "border-destructive",
};

/**
 * Branded custom node. Register it in `nodeTypes={{ brand: FlowNode }}` and
 * create nodes with `type: "brand"` and `data: FlowNodeData`.
 */
export function FlowNode({ data, selected }: NodeProps<BrandFlowNode>) {
  const tone = data.tone ?? "default";
  return (
    <div
      className={cn(
        "min-w-44 rounded-lg border bg-flow-node px-3 py-2 text-flow-node-foreground shadow-sm transition-[box-shadow,border-color] duration-fast ease-standard",
        toneRing[tone],
        selected && "ring-2 ring-ring",
      )}
    >
      <Handle
        type="target"
        position={Position.Top}
        className="!size-2 !border-2 !border-flow-edge !bg-flow-node"
      />
      <div className="flex items-center gap-2">
        {data.icon ? (
          <span className="[&_svg]:size-4 text-muted-foreground">{data.icon}</span>
        ) : null}
        <div className="min-w-0">
          {data.kind ? (
            <div className="text-[10px] font-medium uppercase tracking-wide text-muted-foreground">
              {data.kind}
            </div>
          ) : null}
          <div className="truncate text-sm font-medium">{data.title}</div>
          {data.subtitle ? (
            <div className="truncate text-xs text-muted-foreground">{data.subtitle}</div>
          ) : null}
        </div>
      </div>
      <Handle
        type="source"
        position={Position.Bottom}
        className="!size-2 !border-2 !border-flow-edge !bg-flow-node"
      />
    </div>
  );
}
