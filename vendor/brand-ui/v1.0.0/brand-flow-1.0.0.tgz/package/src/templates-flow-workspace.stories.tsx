/**
 * Story for the registry/templates/flow-workspace template.
 * Shows the full flow workspace page: app-shell + branded React Flow canvas.
 * Remember `import "@xyflow/react/dist/style.css"` is wired in Storybook preview.
 * Verify across all six themes with globals=theme:<slug>.
 */
import type { Meta, StoryObj } from "@storybook/react-vite";
import { useState } from "react";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarHeader,
  SidebarInset,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarProvider,
  SidebarTrigger,
} from "@brand/ui";
import {
  CanvasShell,
  FlowEdge,
  FlowNode,
  ZoomControls,
  useEdgesState,
  useNodesState,
  type BrandFlowNode,
  type Edge,
} from "./index";

const nodeTypes = { brand: FlowNode };
const edgeTypes = { brand: FlowEdge };

const initialNodes: BrandFlowNode[] = [
  {
    id: "ingest",
    type: "brand",
    position: { x: 60, y: 160 },
    data: { kind: "Source", title: "Ingest", subtitle: "Raw data in", tone: "accent" },
  },
  {
    id: "transform",
    type: "brand",
    position: { x: 320, y: 80 },
    data: { kind: "Process", title: "Transform", subtitle: "Normalize & enrich" },
  },
  {
    id: "validate",
    type: "brand",
    position: { x: 320, y: 240 },
    data: { kind: "Process", title: "Validate", subtitle: "Quality checks" },
  },
  {
    id: "publish",
    type: "brand",
    position: { x: 580, y: 160 },
    data: { kind: "Output", title: "Publish", subtitle: "Downstream sink", tone: "success" },
  },
];

const initialEdges: Edge[] = [
  { id: "e-ingest-transform", source: "ingest", target: "transform", type: "brand" },
  { id: "e-ingest-validate", source: "ingest", target: "validate", type: "brand" },
  { id: "e-transform-publish", source: "transform", target: "publish", type: "brand" },
  { id: "e-validate-publish", source: "validate", target: "publish", type: "brand" },
];

const nav = [
  { id: "canvas", label: "Canvas" },
  { id: "layers", label: "Layers" },
  { id: "home", label: "Home" },
  { id: "settings", label: "Settings" },
];

function FlowWorkspaceTemplate() {
  const [active, setActive] = useState("canvas");
  const [nodes, , onNodesChange] = useNodesState(initialNodes);
  const [edges, , onEdgesChange] = useEdgesState(initialEdges);

  return (
    <SidebarProvider>
      <Sidebar collapsible="offcanvas">
        <SidebarHeader className="px-3 py-2 font-semibold">Flow</SidebarHeader>
        <SidebarContent>
          <SidebarGroup>
            <SidebarGroupContent>
              <SidebarMenu>
                {nav.map((n) => (
                  <SidebarMenuItem key={n.id}>
                    <SidebarMenuButton
                      isActive={active === n.id}
                      tooltip={n.label}
                      onClick={() => setActive(n.id)}
                    >
                      <span>{n.label}</span>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                ))}
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        </SidebarContent>
      </Sidebar>
      <SidebarInset className="flex flex-col overflow-hidden">
        <header className="flex h-14 shrink-0 items-center gap-2 border-b px-4">
          <SidebarTrigger />
          <h1 className="text-sm font-medium capitalize">{active}</h1>
        </header>
        <div className="h-[calc(100vh-3.5rem)]">
          <CanvasShell
            className="h-full w-full"
            nodes={nodes}
            edges={edges}
            nodeTypes={nodeTypes}
            edgeTypes={edgeTypes}
            onNodesChange={onNodesChange}
            onEdgesChange={onEdgesChange}
          >
            <ZoomControls />
          </CanvasShell>
        </div>
      </SidebarInset>
    </SidebarProvider>
  );
}

const meta = {
  title: "Templates/Flow Workspace",
  parameters: { layout: "fullscreen" },
  tags: ["autodocs"],
} satisfies Meta;
export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = { render: () => <FlowWorkspaceTemplate /> };
