"use client";

/**
 * useHighDecoration — is the chart rendered in a high-`--decoration` region
 * (blueprint, or any `data-decoration` 8–10 subtree)? Issue #164 / ADR 0011.
 *
 * SVG `fill="url(#pattern)"` cannot be driven from CSS the way the blueprint hatch
 * overlay (`decoration.css`) is — a `<pattern>` def must exist in the SVG and the
 * element's `fill` attribute must reference it. So, uniquely among the blueprint
 * decoration features, charts must participate in JS. This hook is that signal.
 *
 * Detection reads the registered `@property --decoration` custom property off the
 * chart container via `getComputedStyle` (it inherits, and the blueprint theme
 * sets it to 10; a region can set `data-decoration="N"`). This works with NO
 * `ThemeProvider`/`DecorationProvider` — a bare `<BarChart>` under
 * `data-theme="blueprint"` is covered. SSR-safe: the ref is null on the server, so
 * it returns `false` (color) and the first client paint matches (no hydration
 * mismatch); `useLayoutEffect` then flips to pattern pre-paint (no color flash).
 */

import { type RefObject, useLayoutEffect, useState } from "react";
import { useChartStable } from "./chart-context";

/** High decoration begins at level 8 (matches `decoration.css` binary switches). */
const HIGH_DECORATION_THRESHOLD = 8;

/** Read `--decoration` off `el` and decide if it's high. */
function readHigh(el: Element | null): boolean {
  if (!el || typeof window === "undefined") return false;
  const raw = window.getComputedStyle(el).getPropertyValue("--decoration");
  const value = Number.parseFloat(raw);
  return Number.isFinite(value) && value >= HIGH_DECORATION_THRESHOLD;
}

/**
 * Reusable core: is the element `ref` in a high-decoration region? Re-reads when
 * `data-theme`/`data-decoration` change at the document root (covers the Storybook
 * theme toolbar and runtime theme switches).
 */
export function useHighDecorationOf(ref: RefObject<Element | null>): boolean {
  const [high, setHigh] = useState(false);

  useLayoutEffect(() => {
    if (typeof window === "undefined") return;
    let raf = 0;
    const update = () => {
      const el = ref.current;
      if (!el) {
        // The ref may be populated by a PARENT callback ref that fires AFTER this
        // child effect (React commit order) — e.g. PieChart's outer container.
        // Retry on the next frame until it's attached. SSR/unmount → cancelled.
        raf = requestAnimationFrame(update);
        return;
      }
      setHigh(readHigh(el));
    };
    update();
    const observer = new MutationObserver(() => {
      const el = ref.current;
      if (el) setHigh(readHigh(el));
    });
    observer.observe(document.documentElement, {
      attributes: true,
      attributeFilter: ["data-theme", "data-decoration", "class", "style"],
    });
    return () => {
      cancelAnimationFrame(raf);
      observer.disconnect();
    };
  }, [ref]);

  return high;
}

/** Chart-context variant: detects high decoration on the chart container. */
export function useHighDecoration(): boolean {
  const { containerRef } = useChartStable();
  return useHighDecorationOf(containerRef);
}
