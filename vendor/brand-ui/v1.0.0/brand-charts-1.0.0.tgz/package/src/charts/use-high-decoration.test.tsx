import { afterEach, describe, expect, it, vi } from "vitest";
import { createRef } from "react";
import { renderHook } from "@testing-library/react";
import { useHighDecorationOf } from "./use-high-decoration";

/** Stub `getComputedStyle` so `--decoration` returns `value` for any element. */
function stubDecoration(value: string) {
  vi.spyOn(window, "getComputedStyle").mockReturnValue({
    getPropertyValue: (prop: string) => (prop === "--decoration" ? value : ""),
  } as unknown as CSSStyleDeclaration);
}

afterEach(() => vi.restoreAllMocks());

describe("useHighDecorationOf (#164)", () => {
  it("is true when --decoration ≥ 8 (blueprint = 10)", () => {
    stubDecoration("10");
    const ref = createRef<HTMLDivElement>();
    // attach a real element so the effect reads it
    (ref as { current: HTMLDivElement }).current = document.createElement("div");
    const { result } = renderHook(() => useHighDecorationOf(ref));
    expect(result.current).toBe(true);
  });

  it("is false at low decoration (chromatic themes)", () => {
    stubDecoration("3");
    const ref = createRef<HTMLDivElement>();
    (ref as { current: HTMLDivElement }).current = document.createElement("div");
    const { result } = renderHook(() => useHighDecorationOf(ref));
    expect(result.current).toBe(false);
  });

  it("is false when the ref is unattached (SSR / pre-mount)", () => {
    stubDecoration("10");
    const ref = createRef<HTMLDivElement>();
    const { result } = renderHook(() => useHighDecorationOf(ref));
    expect(result.current).toBe(false);
  });

  it("is false when --decoration is absent/empty", () => {
    stubDecoration("");
    const ref = createRef<HTMLDivElement>();
    (ref as { current: HTMLDivElement }).current = document.createElement("div");
    const { result } = renderHook(() => useHighDecorationOf(ref));
    expect(result.current).toBe(false);
  });
});
